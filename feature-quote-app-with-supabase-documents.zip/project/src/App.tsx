import { useState } from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import LandingPage from '@/pages/LandingPage';
import QuotePage from '@/pages/QuotePage';
import ClientPortalPage from '@/pages/ClientPortalPage';
import StaffPortalPage from '@/pages/StaffPortalPage';
import ProductsPage from '@/pages/ProductsPage';

export type Page = 'landing' | 'products' | 'quote' | 'portal' | 'staff';

function App() {
  const [page, setPage] = useState<Page>('landing');

  return (
    <div className="flex min-h-screen flex-col bg-white font-sans text-slate-900">
      <Header page={page} onNavigate={setPage} />
      <main className="flex-1">
        {page === 'landing' && <LandingPage onNavigate={setPage} />}
        {page === 'products' && <ProductsPage onNavigate={setPage} />}
        {page === 'quote' && <QuotePage />}
        {page === 'portal' && <ClientPortalPage />}
        {page === 'staff' && <StaffPortalPage />}
      </main>
      {page === 'landing' && <Footer onNavigate={setPage} />}
    </div>
  );
}

export default App;
