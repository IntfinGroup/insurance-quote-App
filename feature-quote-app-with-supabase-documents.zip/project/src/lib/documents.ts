import { supabase } from '@/lib/supabase';

export type DocumentStatus = 'required' | 'uploaded' | 'under_review' | 'accepted' | 'rejected';
export type DocumentType =
  | 'id_document'
  | 'proof_of_address'
  | 'drivers_licence'
  | 'vehicle_registration'
  | 'bank_confirmation'
  | 'valuation'
  | 'invoice'
  | 'policy_schedule'
  | 'claim_document'
  | 'supporting_document'
  | 'other';

export interface ClientDocument {
  id: string;
  client_id: string;
  quote_id: string | null;
  uploaded_by: string;
  file_name: string;
  file_path: string;
  document_type: DocumentType;
  status: DocumentStatus;
  file_size: number;
  mime_type: string;
  rejection_reason: string | null;
  reviewed_at: string | null;
  reviewed_by: string | null;
  created_at: string;
  updated_at: string;
}

export const DOCUMENT_TYPE_LABELS: Record<DocumentType, string> = {
  id_document: 'ID Document',
  proof_of_address: 'Proof of Address',
  drivers_licence: "Driver's Licence",
  vehicle_registration: 'Vehicle Registration',
  bank_confirmation: 'Bank Confirmation',
  valuation: 'Valuation',
  invoice: 'Invoice',
  policy_schedule: 'Policy Schedule',
  claim_document: 'Claim Document',
  supporting_document: 'Supporting Document',
  other: 'Other',
};

export async function listClientDocuments(clientId: string, quoteId?: string) {
  let query = supabase.from('documents').select('*').eq('client_id', clientId).order('created_at', { ascending: false });
  if (quoteId) query = query.eq('quote_id', quoteId);
  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []) as ClientDocument[];
}

export async function uploadDocument(params: {
  clientId: string;
  quoteId?: string | null;
  documentType: DocumentType;
  file: File;
  uploadedBy: 'client' | 'staff';
}) {
  const safeName = params.file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const path = `${params.clientId}/${params.quoteId ?? 'general'}/${crypto.randomUUID()}-${safeName}`;

  const { error: uploadError } = await supabase.storage.from('insurance-documents').upload(path, params.file, {
    cacheControl: '3600',
    upsert: false,
    contentType: params.file.type || 'application/octet-stream',
  });
  if (uploadError) throw uploadError;

  const { data, error } = await supabase.from('documents').insert({
    client_id: params.clientId,
    quote_id: params.quoteId ?? null,
    uploaded_by: params.uploadedBy,
    file_name: params.file.name,
    file_path: path,
    document_type: params.documentType,
    status: 'uploaded',
    file_size: params.file.size,
    mime_type: params.file.type || 'application/octet-stream',
  }).select('*').single();

  if (error) {
    await supabase.storage.from('insurance-documents').remove([path]);
    throw error;
  }
  return data as ClientDocument;
}

export async function getDocumentDownloadUrl(filePath: string) {
  const { data, error } = await supabase.storage.from('insurance-documents').createSignedUrl(filePath, 300);
  if (error) throw error;
  return data.signedUrl;
}

export async function updateDocumentStatus(id: string, status: DocumentStatus, reason?: string) {
  const { error } = await supabase.from('documents').update({
    status,
    rejection_reason: status === 'rejected' ? reason ?? null : null,
    reviewed_at: new Date().toISOString(),
    reviewed_by: 'staff',
    updated_at: new Date().toISOString(),
  }).eq('id', id);
  if (error) throw error;
}

export async function deleteDocument(document: ClientDocument) {
  const { error: storageError } = await supabase.storage.from('insurance-documents').remove([document.file_path]);
  if (storageError) throw storageError;
  const { error } = await supabase.from('documents').delete().eq('id', document.id);
  if (error) throw error;
}
