import { supabase } from '@/lib/supabase';
import {
  AllRiskItem,
  Client,
  ClientDetails,
  HomeInput,
  LiabilityInput,
  PleasureCraftInput,
  TrailerInput,
  PremiumBreakdown,
  Quote,
  QuoteStatus,
  QuoteWithClient,
  VehicleInput,
} from '@/types/insurance';

function generateQuoteNumber(): string {
  const year = new Date().getFullYear();
  const suffix = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `FI-${year}-${suffix}`;
}

export async function findOrCreateClient(details: ClientDetails): Promise<Client> {
  const { data: existing, error: findError } = await supabase
    .from('clients')
    .select('*')
    .eq('mobile', details.mobile)
    .maybeSingle();

  if (findError) throw findError;
  if (existing) return existing as Client;

  const { data: created, error: insertError } = await supabase
    .from('clients')
    .insert({ full_name: details.fullName, mobile: details.mobile, email: details.email })
    .select('*')
    .single();

  if (insertError) throw insertError;
  return created as Client;
}

interface CreateQuotePayload {
  clientId: string;
  status: QuoteStatus;
  vehicleSection: VehicleInput | null;
  homeSection: HomeInput | null;
  allRiskSection: AllRiskItem[] | null;
  liabilitySection: LiabilityInput | null;
  pleasureCraftSection: PleasureCraftInput | null;
  trailerSection: TrailerInput | null;
  premiumBreakdown: PremiumBreakdown;
  totalMonthlyPremium: number;
  tags: string[];
  referralReasons: string[];
}

export async function createQuote(payload: CreateQuotePayload): Promise<Quote> {
  const { data, error } = await supabase
    .from('quotes')
    .insert({
      client_id: payload.clientId,
      quote_number: generateQuoteNumber(),
      status: payload.status,
      vehicle_section: payload.vehicleSection,
      home_section: payload.homeSection,
      all_risk_section: payload.allRiskSection,
      liability_section: payload.liabilitySection,
      pleasure_craft_section: payload.pleasureCraftSection,
      trailer_section: payload.trailerSection,
      premium_breakdown: payload.premiumBreakdown,
      total_monthly_premium: payload.totalMonthlyPremium,
      tags: payload.tags,
      referral_reasons: payload.referralReasons,
    })
    .select('*')
    .single();

  if (error) throw error;
  return data as Quote;
}

export async function fetchQuotesByMobile(mobile: string): Promise<QuoteWithClient[]> {
  const { data, error } = await supabase
    .from('quotes')
    .select('*, client:clients!inner(*)')
    .eq('client.mobile', mobile)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data as QuoteWithClient[];
}

export async function fetchAllQuotes(): Promise<QuoteWithClient[]> {
  const { data, error } = await supabase
    .from('quotes')
    .select('*, client:clients(*)')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data as QuoteWithClient[];
}

export async function updateQuoteStatus(quoteId: string, status: QuoteStatus): Promise<void> {
  const { error } = await supabase
    .from('quotes')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', quoteId);

  if (error) throw error;
}

interface UpdateQuoteSectionsPayload {
  vehicleSection: VehicleInput | null;
  homeSection: HomeInput | null;
  allRiskSection: AllRiskItem[] | null;
  liabilitySection: LiabilityInput | null;
  pleasureCraftSection: PleasureCraftInput | null;
  trailerSection: TrailerInput | null;
  premiumBreakdown: PremiumBreakdown;
  totalMonthlyPremium: number;
  tags: string[];
  referralReasons: string[];
  status: QuoteStatus;
}

export async function updateQuoteSections(quoteId: string, payload: UpdateQuoteSectionsPayload): Promise<void> {
  const { error } = await supabase
    .from('quotes')
    .update({
      vehicle_section: payload.vehicleSection,
      home_section: payload.homeSection,
      all_risk_section: payload.allRiskSection,
      liability_section: payload.liabilitySection,
      pleasure_craft_section: payload.pleasureCraftSection,
      trailer_section: payload.trailerSection,
      premium_breakdown: payload.premiumBreakdown,
      total_monthly_premium: payload.totalMonthlyPremium,
      tags: payload.tags,
      referral_reasons: payload.referralReasons,
      status: payload.status,
      updated_at: new Date().toISOString(),
    })
    .eq('id', quoteId);

  if (error) throw error;
}

export async function applyAdminOverride(
  quoteId: string,
  overridePremium: number,
  status: QuoteStatus,
  reason: string,
): Promise<void> {
  const { error } = await supabase
    .from('quotes')
    .update({
      total_monthly_premium: overridePremium,
      status,
      admin_override: true,
      override_reason: reason,
      updated_at: new Date().toISOString(),
    })
    .eq('id', quoteId);

  if (error) throw error;
}

export async function insertAuditLog(entry: {
  quoteId: string;
  staffName: string;
  action: string;
  reason: string;
  oldValue: unknown;
  newValue: unknown;
}): Promise<void> {
  const { error } = await supabase.from('quote_audit_log').insert({
    quote_id: entry.quoteId,
    staff_name: entry.staffName,
    action: entry.action,
    reason: entry.reason,
    old_value: entry.oldValue,
    new_value: entry.newValue,
  });

  if (error) throw error;
}

export async function fetchAuditLog(quoteId: string) {
  const { data, error } = await supabase
    .from('quote_audit_log')
    .select('*')
    .eq('quote_id', quoteId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}
