import {
  AllRiskCategory,
  AllRiskItem,
  AllRiskItemResult,
  AllRiskResult,
  HomeInput,
  HomeResult,
  LiabilityInput,
  LiabilityResult,
  PleasureCraftInput,
  PleasureCraftResult,
  TrailerInput,
  TrailerResult,
  PremiumBreakdown,
  QuoteCalculation,
  VehicleInput,
  VehicleResult,
} from '@/types/insurance';

const VEHICLE_MIN_MONTHLY_PREMIUM = 250;
const VEHICLE_EXTRAS_RATE = 0.02;
const VEHICLE_YOUNG_DRIVER_AGE = 25;
const VEHICLE_REFERRAL_RETAIL_VALUE = 2_000_000;

const VEHICLE_BRACKETS = [
  { upTo: 100_000, rate: 0.06 },
  { upTo: 200_000, rate: 0.05 },
  { upTo: 300_000, rate: 0.04 },
  { upTo: 400_000, rate: 0.035 },
  { upTo: 500_000, rate: 0.03125 },
  { upTo: Infinity, rate: 0.03 },
];

const BUILDING_RATE = 0.002;
const BUILDING_THATCH_RATE = 0.01;
const CONTENTS_RATE = 0.007;
const CONTENTS_THATCH_RATE = 0.01;
const CONTENTS_MIN_SUM_INSURED = 250_000;
const NEXT_LEVEL_ASSET_THRESHOLD = 5_000_000;
const HOME_REFERRAL_THRESHOLD = 20_000_000;

const TRAILER_MIN_MONTHLY_PREMIUM = 25;
const TRAILER_RANGE_LOW = 0.02;
const TRAILER_RANGE_HIGH = 0.04;
const WATERCRAFT_RANGE_LOW = 0.02;
const WATERCRAFT_RANGE_HIGH = 0.04;

const ALL_RISK_RATES: Record<AllRiskCategory, number> = {
  laptops_ipads_cellphones: 0.12,
  jewelry: 0.04,
  cameras_glasses_firearms: 0.06,
  clothing_camping: 0.075,
  pedal_cycles: 0.08,
};

const round2 = (value: number) => Math.round(value * 100) / 100;

function vehicleBracketRate(sumInsured: number): number {
  const bracket = VEHICLE_BRACKETS.find((b) => sumInsured <= b.upTo);
  return bracket ? bracket.rate : VEHICLE_BRACKETS[VEHICLE_BRACKETS.length - 1].rate;
}

export function calculateVehiclePremium(input: VehicleInput): VehicleResult {
  const baseRatePct = vehicleBracketRate(input.sumInsured);
  const loadingPct = input.driverAge < VEHICLE_YOUNG_DRIVER_AGE || input.licenseCode === 'C1' ? 0.005 : 0;
  const effectiveRatePct = baseRatePct + loadingPct;

  const rawMonthlyPremium = (input.sumInsured * effectiveRatePct) / 12;
  const basePremium = Math.max(rawMonthlyPremium, VEHICLE_MIN_MONTHLY_PREMIUM);
  const minimumApplied = rawMonthlyPremium < VEHICLE_MIN_MONTHLY_PREMIUM;

  const extrasPremium = (input.extrasValue * VEHICLE_EXTRAS_RATE) / 12;
  const totalPremium = round2(basePremium + extrasPremium);

  const referral = input.retailValue > VEHICLE_REFERRAL_RETAIL_VALUE;

  return {
    baseRatePct,
    loadingPct,
    effectiveRatePct,
    basePremium: round2(basePremium),
    extrasPremium: round2(extrasPremium),
    totalPremium,
    referral,
    referralReason: referral
      ? `Vehicle retail value (R${input.retailValue.toLocaleString('en-ZA')}) exceeds R2,000,000`
      : null,
    minimumApplied,
  };
}

export function calculateHomePremium(input: HomeInput): HomeResult {
  const buildingRate = input.thatchRoof ? BUILDING_THATCH_RATE : BUILDING_RATE;
  const contentsRate = input.thatchRoof ? CONTENTS_THATCH_RATE : CONTENTS_RATE;

  const buildingSumInsured = input.includeBuilding ? input.buildingSumInsured : 0;
  const contentsSumInsured = input.includeContents ? input.contentsSumInsured : 0;
  const ratedContentsSumInsured = input.includeContents
    ? Math.max(contentsSumInsured, CONTENTS_MIN_SUM_INSURED)
    : 0;

  const buildingPremium = input.includeBuilding ? round2((buildingSumInsured * buildingRate) / 12) : 0;
  const contentsPremium = input.includeContents
    ? round2((ratedContentsSumInsured * contentsRate) / 12)
    : 0;

  const combinedSumInsured = buildingSumInsured + contentsSumInsured;
  const tags: string[] = [];
  if (combinedSumInsured > NEXT_LEVEL_ASSET_THRESHOLD) {
    tags.push('Next Level Asset');
  }

  const referral = combinedSumInsured > HOME_REFERRAL_THRESHOLD;

  return {
    buildingPremium,
    contentsPremium,
    ratedContentsSumInsured,
    totalPremium: round2(buildingPremium + contentsPremium),
    tags,
    referral,
    referralReason: referral
      ? `Combined building and contents sum insured (R${combinedSumInsured.toLocaleString('en-ZA')}) exceeds R20,000,000`
      : null,
  };
}

export function calculateAllRiskPremium(items: AllRiskItem[]): AllRiskResult {
  const results: AllRiskItemResult[] = items.map((item) => {
    const ratePct = ALL_RISK_RATES[item.category];
    const premium = round2((item.value * ratePct) / 12);
    return { ...item, ratePct, premium };
  });

  return {
    items: results,
    totalPremium: round2(results.reduce((sum, item) => sum + item.premium, 0)),
  };
}

export function calculateLiabilityPremium(_input: LiabilityInput): LiabilityResult {
  return {
    premium: 0,
    referral: true,
    referralReason:
      'Liability requires underwriting referral because the supplied F4M material does not define a complete Feature rating formula.',
  };
}

export function calculatePleasureCraftPremium(input: PleasureCraftInput): PleasureCraftResult {
  const minPremium = round2((input.sumInsured * WATERCRAFT_RANGE_LOW) / 12);
  const maxPremium = round2((input.sumInsured * WATERCRAFT_RANGE_HIGH) / 12);

  return {
    premium: 0,
    indicativeMinPremium: minPremium,
    indicativeMaxPremium: maxPremium,
    referral: true,
    referralReason:
      `Pleasure Craft rate is supplied as a 2%–4% value-based range; underwriter rate confirmation is required. Indicative range: R${minPremium.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}–R${maxPremium.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}/month.`,
  };
}

export function calculateTrailerPremium(input: TrailerInput): TrailerResult {
  if (input.coverType === 'third_party_only') {
    const monthly = input.trailerType === 'caravan' ? 50 : 20;
    return {
      premium: monthly,
      indicativeMinPremium: monthly,
      indicativeMaxPremium: monthly,
      referral: false,
      referralReason: '',
    };
  }

  const minPremium = Math.max(round2((input.sumInsured * TRAILER_RANGE_LOW) / 12), TRAILER_MIN_MONTHLY_PREMIUM);
  const maxPremium = Math.max(round2((input.sumInsured * TRAILER_RANGE_HIGH) / 12), TRAILER_MIN_MONTHLY_PREMIUM);

  return {
    premium: 0,
    indicativeMinPremium: minPremium,
    indicativeMaxPremium: maxPremium,
    referral: true,
    referralReason:
      `Trailer/Caravan comprehensive rate is supplied as a 2%–4% value-based range with a noted R25 minimum; underwriter rate confirmation is required. Indicative range: R${minPremium.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}–R${maxPremium.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}/month.`,
  };
}

export function calculateQuote(
  vehicle: VehicleInput | null,
  home: HomeInput | null,
  allRiskItems: AllRiskItem[] | null,
  liability: LiabilityInput | null = null,
  pleasureCraft: PleasureCraftInput | null = null,
  trailer: TrailerInput | null = null,
): QuoteCalculation {
  const vehicleResult = vehicle?.included ? calculateVehiclePremium(vehicle) : null;
  const homeResult = home && (home.includeBuilding || home.includeContents) ? calculateHomePremium(home) : null;
  const allRiskResult = allRiskItems && allRiskItems.length > 0 ? calculateAllRiskPremium(allRiskItems) : null;
  const liabilityResult = liability?.included ? calculateLiabilityPremium(liability) : null;
  const pleasureCraftResult = pleasureCraft?.included ? calculatePleasureCraftPremium(pleasureCraft) : null;
  const trailerResult = trailer?.included ? calculateTrailerPremium(trailer) : null;

  const breakdown: PremiumBreakdown = {
    vehicle: vehicleResult?.totalPremium ?? 0,
    building: homeResult?.buildingPremium ?? 0,
    contents: homeResult?.contentsPremium ?? 0,
    allRisk: allRiskResult?.totalPremium ?? 0,
    liability: liabilityResult?.premium ?? 0,
    pleasureCraft: pleasureCraftResult?.premium ?? 0,
    trailer: trailerResult?.premium ?? 0,
    total: round2(
      (vehicleResult?.totalPremium ?? 0) +
        (homeResult?.totalPremium ?? 0) +
        (allRiskResult?.totalPremium ?? 0) +
        (liabilityResult?.premium ?? 0) +
        (pleasureCraftResult?.premium ?? 0) +
        (trailerResult?.premium ?? 0),
    ),
  };

  const tags = [...(homeResult?.tags ?? [])];
  const referralReasons = [
    vehicleResult?.referralReason,
    homeResult?.referralReason,
    liabilityResult?.referralReason,
    pleasureCraftResult?.referralReason,
    trailerResult?.referralReason,
  ].filter((reason): reason is string => Boolean(reason));

  const status = referralReasons.length > 0 ? 'referred' : 'quoted';

  return {
    vehicle: vehicleResult,
    home: homeResult,
    allRisk: allRiskResult,
    liability: liabilityResult,
    pleasureCraft: pleasureCraftResult,
    trailer: trailerResult,
    breakdown,
    tags,
    referralReasons,
    status,
  };
}
