import { useMemo, useState } from 'react';
import { Page } from '@/App';
import {
  Calculator,
  Car,
  Home as HomeIcon,
  Gem,
  ShieldAlert,
  ArrowRight,
  Info,
} from 'lucide-react';
import { formatCurrency } from '@/lib/format';

type CalcCategory =
  | 'vehicle'
  | 'tpo'
  | 'tpft'
  | 'credit'
  | 'building'
  | 'content'
  | 'allrisk'
  | 'pa';

type TpoType = 'vehicle' | 'trailer' | 'caravan';
type AllRiskType =
  | 'jewelry'
  | 'clothing'
  | 'cellphone'
  | 'laptop'
  | 'camera'
  | 'firearm'
  | 'drone'
  | 'pedal_cycles'
  | 'other';

const ALL_RISK_RATES: Record<AllRiskType, number> = {
  jewelry: 0.04,
  clothing: 0.075,
  cellphone: 0.12,
  laptop: 0.12,
  camera: 0.06,
  firearm: 0.06,
  drone: 0.1,
  pedal_cycles: 0.08,
  other: 0.075,
};

const TPO_RATES: Record<TpoType, number> = {
  vehicle: 120,
  trailer: 20,
  caravan: 50,
};

const VEHICLE_BRACKETS = [
  { upTo: 100_000, rate: 0.06, label: '6.0%' },
  { upTo: 200_000, rate: 0.05, label: '5.0%' },
  { upTo: 300_000, rate: 0.045, label: '4.5%' },
  { upTo: 400_000, rate: 0.0375, label: '3.75%' },
  { upTo: 500_000, rate: 0.0325, label: '3.25%' },
  { upTo: Infinity, rate: 0.03, label: '3.0%' },
];

const CATEGORY_LABELS: Record<CalcCategory, string> = {
  vehicle: 'Comprehensive Vehicle',
  tpo: 'Third Party Only',
  tpft: 'Third Party, Fire & Theft',
  credit: 'Credit Shortfall',
  building: 'Home Owners (Building)',
  content: 'Household Content',
  allrisk: 'All Risk Items',
  pa: 'Personal Accident',
};

const ALL_RISK_OPTIONS: { value: AllRiskType; label: string }[] = [
  { value: 'cellphone', label: 'Cellular Phones (12%)' },
  { value: 'laptop', label: 'Laptops / iPads (12%)' },
  { value: 'drone', label: 'Drones (~10%)' },
  { value: 'pedal_cycles', label: 'Pedal Cycles (8%)' },
  { value: 'clothing', label: 'Clothing & Effects (7.5%)' },
  { value: 'other', label: 'Smartwatches & Other (7.5%)' },
  { value: 'camera', label: 'Cameras / Lenses (6%)' },
  { value: 'firearm', label: 'Firearms (6%)' },
  { value: 'jewelry', label: 'Jewelry (4%)' },
];

const TPO_OPTIONS: { value: TpoType; label: string }[] = [
  { value: 'vehicle', label: 'Vehicle (R120/mo)' },
  { value: 'caravan', label: 'Caravan (R50/mo)' },
  { value: 'trailer', label: 'Trailer (R20/mo)' },
];

const round2 = (v: number) => Math.round(v * 100) / 100;

interface CalcResult {
  monthly: number;
  note: string;
}

function calculate(category: CalcCategory, sumInsured: number, subCategory: string): CalcResult {
  switch (category) {
    case 'vehicle': {
      const bracket = VEHICLE_BRACKETS.find((b) => sumInsured <= b.upTo) ?? VEHICLE_BRACKETS[VEHICLE_BRACKETS.length - 1];
      let monthly = (sumInsured * bracket.rate) / 12;
      const minApplied = monthly < 250;
      if (minApplied) monthly = 250;
      return {
        monthly: round2(monthly),
        note: `Rate applied: ${bracket.label}. ${minApplied ? 'Minimum premium of R250 applied.' : ''}`,
      };
    }
    case 'tpo': {
      const type = subCategory as TpoType;
      return { monthly: TPO_RATES[type], note: 'Flat monthly rate for Third Party Only cover.' };
    }
    case 'tpft':
      return { monthly: round2((sumInsured * 0.005) / 12), note: 'Third Party, Fire & Theft rate applied (0.5%).' };
    case 'credit': {
      const capped = Math.min(sumInsured, 250_000);
      return {
        monthly: round2((capped * 0.015) / 12),
        note: capped === 250_000 ? 'Max cover limit of R250,000 applied at 1.5%.' : 'Credit Shortfall rate of 1.5% applied.',
      };
    }
    case 'pa': {
      const capped = Math.min(sumInsured, 250_000);
      return {
        monthly: round2((capped * 0.002) / 12),
        note: capped === 250_000 ? 'Max cover limit of R250,000 applied at 0.2%.' : 'Personal Accident rate of 0.2% applied.',
      };
    }
    case 'building':
      return { monthly: round2((sumInsured * 0.002) / 12), note: 'Standard building rate of 0.2% applied. Thatch roof requires 1%.' };
    case 'content': {
      const floored = Math.max(sumInsured, 250_000);
      return {
        monthly: round2((floored * 0.007) / 12),
        note: floored === 250_000 ? 'Minimum sum insured of R250,000 applied at 0.7%.' : 'Standard content rate of 0.7% applied. Thatch roof requires 1%.',
      };
    }
    case 'allrisk': {
      const rate = ALL_RISK_RATES[subCategory as AllRiskType];
      return { monthly: round2((sumInsured * rate) / 12), note: `All Risk rate applied: ${(rate * 100).toFixed(1)}%.` };
    }
  }
}

const needsSumInsured = (cat: CalcCategory) => cat !== 'tpo';
const needsSubCategory = (cat: CalcCategory) => cat === 'allrisk' || cat === 'tpo';

export default function ProductsPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const [category, setCategory] = useState<CalcCategory>('vehicle');
  const [subCategory, setSubCategory] = useState<string>('');
  const [sumInsured, setSumInsured] = useState('');
  const [result, setResult] = useState<CalcResult | null>(null);
  const [error, setError] = useState('');

  const subOptions = useMemo(() => {
    if (category === 'allrisk') return ALL_RISK_OPTIONS;
    if (category === 'tpo') return TPO_OPTIONS;
    return [];
  }, [category]);

  const handleCalculate = () => {
    setError('');
    const value = Number(sumInsured);

    if (needsSubCategory(category) && !subCategory) {
      setError('Please select a sub-category.');
      return;
    }
    if (needsSumInsured(category) && (!sumInsured || value <= 0)) {
      setError('Please enter a valid sum insured.');
      return;
    }

    setResult(calculate(category, value, subCategory));
  };

  const handleCategoryChange = (cat: CalcCategory) => {
    setCategory(cat);
    setSubCategory('');
    setResult(null);
    setError('');
  };

  return (
    <div className="bg-slate-50">
      {/* Header */}
      <section className="bg-navy-950 py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl lg:text-5xl">
            Products &amp; Premium Rates
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-300">
            Comprehensive coverage guidelines and calculations for all our products.
          </p>
        </div>
      </section>

      {/* Quick Calculator */}
      <section className="-mt-8 pb-4">
        <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8">
          <div className="rounded-2xl bg-white p-6 shadow-xl ring-1 ring-slate-200 sm:p-8">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-50">
                <Calculator className="h-5 w-5 text-teal-600" />
              </span>
              <div>
                <h2 className="text-xl font-bold text-navy-900">Quick Estimator</h2>
                <p className="text-sm text-slate-500">Select a category and enter a sum insured to calculate base premiums.</p>
              </div>
            </div>

            <div className="mt-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700">Cover Category</label>
                <select
                  value={category}
                  onChange={(e) => handleCategoryChange(e.target.value as CalcCategory)}
                  className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                >
                  {(Object.keys(CATEGORY_LABELS) as CalcCategory[]).map((cat) => (
                    <option key={cat} value={cat}>{CATEGORY_LABELS[cat]}</option>
                  ))}
                </select>
              </div>

              {needsSubCategory(category) && (
                <div>
                  <label className="block text-sm font-medium text-slate-700">
                    {category === 'allrisk' ? 'Item Type' : 'Vehicle Type'}
                  </label>
                  <select
                    value={subCategory}
                    onChange={(e) => { setSubCategory(e.target.value); setResult(null); }}
                    className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    <option value="">Select...</option>
                    {subOptions.map((opt) => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
              )}

              {needsSumInsured(category) && (
                <div>
                  <label className="block text-sm font-medium text-slate-700">Sum Insured (ZAR)</label>
                  <input
                    type="number"
                    value={sumInsured}
                    onChange={(e) => { setSumInsured(e.target.value); setResult(null); }}
                    placeholder="e.g. 150000"
                    className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>
              )}

              {error && <p className="text-sm text-red-600">{error}</p>}

              <button
                onClick={handleCalculate}
                className="w-full rounded-md bg-teal-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-500"
              >
                Calculate Estimated Monthly Premium
              </button>
            </div>

            {result && (
              <div className="mt-6 rounded-xl bg-teal-50 p-5 text-center ring-1 ring-teal-100">
                <p className="text-sm text-slate-600">Estimated Monthly Premium</p>
                <p className="mt-1 text-3xl font-bold text-teal-700">{formatCurrency(result.monthly)}</p>
                <p className="mt-2 text-xs text-slate-500">{result.note}</p>
                <button
                  onClick={() => onNavigate('quote')}
                  className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-teal-700 hover:text-teal-800"
                >
                  Get a full quote <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Rate Reference Cards */}
      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-navy-900">Rate Reference</h2>
          <p className="mt-1 text-sm text-slate-600">Full rate tables for all our cover types.</p>

          <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {/* Vehicles */}
            <RateCard icon={Car} title="1. Vehicles" subtitle="Comprehensive rates (Min R250)" accent="blue">
              <RateRow label="R0 - R100,000" value="6.0%" />
              <RateRow label="R100,001 - R200,000" value="5.0%" />
              <RateRow label="R200,001 - R300,000" value="3.75% - 4.5%" />
              <RateRow label="R300,001 - R400,000" value="3.25% - 3.75%" />
              <RateRow label="R400,001 - R500,000" value="3.0% - 3.25%" />
              <RateRow label="> R500,000" value="3.0%" last />
              <div className="mt-4 border-t border-slate-100 pt-3">
                <p className="text-xs font-semibold text-slate-600">Additional Vehicle Types</p>
                <ul className="mt-1.5 space-y-1 text-xs text-slate-500">
                  <li>Trailers / Caravans: 2% - 4%</li>
                  <li>Watercraft: 2% - 4%</li>
                  <li>Motorcycles: 3% - 6%</li>
                </ul>
              </div>
            </RateCard>

            {/* Alternative Vehicle Cover */}
            <RateCard icon={ShieldAlert} title="2. Alternative Vehicle Cover" subtitle="TPO, TPFT & Credit Shortfall" accent="teal">
              <div className="mb-4">
                <p className="text-xs font-semibold text-slate-600">Third Party Only</p>
                <ul className="mt-1.5 space-y-1 text-xs text-slate-500">
                  <li>Vehicles: R120 / month</li>
                  <li>Trailers: R20 / month</li>
                  <li>Caravans: R50 / month</li>
                </ul>
              </div>
              <div className="mb-4 border-t border-slate-100 pt-3">
                <p className="text-xs font-semibold text-slate-600">Third Party, Fire & Theft</p>
                <p className="mt-1 text-xs text-slate-500">0.5% of sum insured</p>
              </div>
              <div className="border-t border-slate-100 pt-3">
                <p className="text-xs font-semibold text-slate-600">Credit Shortfall</p>
                <p className="mt-1 text-xs text-slate-500">1.5% rate (Max cover R250,000)</p>
              </div>
            </RateCard>

            {/* All Risk */}
            <RateCard icon={Gem} title="3. All Risk Items" subtitle="Specified possessions cover" accent="blue">
              <RateRow label="Cellphones / Laptops / iPads" value="12.0%" />
              <RateRow label="Drones" value="8.0% - 12.0%" />
              <RateRow label="Clothing / Smartwatches" value="7.5%" />
              <RateRow label="Pedal Cycles" value="8.0%" />
              <RateRow label="Cameras / Firearms" value="6.0%" />
              <RateRow label="Jewelry" value="4.0%" />
              <RateRow label="All Other Items" value="7.5%" last />
            </RateCard>

            {/* Home & Property */}
            <RateCard icon={HomeIcon} title="4. Home & Property" subtitle="Building and contents cover" accent="teal">
              <div className="mb-4">
                <p className="text-xs font-semibold text-slate-600">Household Content</p>
                <p className="mt-1 text-xs text-slate-500">Minimum rate: 0.7% (Thatch: 1%)</p>
                <p className="text-xs text-slate-500">Minimum insured: R250,000</p>
              </div>
              <div className="border-t border-slate-100 pt-3">
                <p className="text-xs font-semibold text-slate-600">Home Owners (Building)</p>
                <p className="mt-1 text-xs text-slate-500">Standard rate: 0.2% (Thatch: 1%)</p>
              </div>
              <div className="mt-4 flex items-start gap-2 rounded-lg bg-amber-50 p-3 text-xs text-amber-800 ring-1 ring-amber-200">
                <Info className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" />
                <span>Content &amp; Building combined &gt; R5M requires Next Level Asset cover. &gt; R20M requires direct approval.</span>
              </div>
            </RateCard>

            {/* Personal Accident */}
            <RateCard icon={ShieldAlert} title="5. Personal Accident" subtitle="Accidental injury cover" accent="blue">
              <p className="text-sm text-slate-600">Coverage for unforeseen personal accidents and injuries.</p>
              <div className="mt-4 rounded-lg bg-slate-50 p-4 ring-1 ring-slate-200">
                <p className="text-xs font-semibold text-slate-700">Maximum Cover</p>
                <p className="mt-1 text-lg font-bold text-teal-600">{formatCurrency(250_000)}</p>
                <p className="mt-1 text-xs text-slate-500">Rate: 0.2% of sum insured. Only choose appropriate extension.</p>
              </div>
            </RateCard>

            {/* General Rules & Additions */}
            <RateCard icon={Info} title="6. General Rules & Additions" subtitle="Loadings, limits and referrals" accent="teal">
              <ul className="space-y-2.5 text-sm text-slate-600">
                <li><span className="font-semibold">Young Drivers:</span> Load rate by 0.5% if under 25 or C1 license.</li>
                <li><span className="font-semibold">Security:</span> Always add immobilizer for vehicles after 1998.</li>
                <li><span className="font-semibold">High Value:</span> Vehicles &gt; R2M or Home/Content &gt; R20M require Franco&apos;s approval.</li>
                <li><span className="font-semibold">Track Days:</span> Cover confirmation for Track School Days must be referred.</li>
              </ul>
            </RateCard>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-navy-900 py-14">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-white sm:text-3xl">Ready to generate a proposal?</h2>
          <p className="mt-3 text-slate-300">
            Transition seamlessly from these rate guidelines to a fully calculated client quote.
          </p>
          <button
            onClick={() => onNavigate('quote')}
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-teal-500 px-8 py-3 text-sm font-bold text-navy-950 shadow-lg transition-all hover:-translate-y-0.5 hover:bg-teal-400"
          >
            Go to Quoting Engine <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </section>
    </div>
  );
}

const ACCENT_CLASSES: Record<string, string> = {
  blue: 'text-blue-600',
  red: 'text-red-600',
  teal: 'text-teal-600',
  green: 'text-green-600',
  navy: 'text-navy-600',
  slate: 'text-slate-600',
};

function RateCard({
  icon: Icon,
  title,
  subtitle,
  accent,
  children,
}: {
  icon: typeof Car;
  title: string;
  subtitle: string;
  accent: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
      <div className="flex items-center gap-3">
        <span className={`flex h-10 w-10 items-center justify-center rounded-lg bg-slate-50 ${ACCENT_CLASSES[accent]}`}>
          <Icon className="h-5 w-5" />
        </span>
        <div>
          <h3 className="text-lg font-bold text-navy-900">{title}</h3>
          <p className="text-xs text-slate-500">{subtitle}</p>
        </div>
      </div>
      <div className="mt-4">{children}</div>
    </div>
  );
}

function RateRow({ label, value, last }: { label: string; value: string; last?: boolean }) {
  return (
    <div className={`flex items-center justify-between text-sm ${last ? '' : 'border-b border-slate-100 pb-1.5'} ${last ? 'pt-0' : 'pt-1.5'}`}>
      <span className="text-slate-600">{label}</span>
      <span className="font-semibold text-teal-600">{value}</span>
    </div>
  );
}
