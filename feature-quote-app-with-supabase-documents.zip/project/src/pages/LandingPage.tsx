import {
  Car,
  Home as HomeIcon,
  Gem,
  ArrowRight,
  ShieldCheck,
  Zap,
  Headset,
  BadgeCheck,
  ClipboardList,
  Sliders,
  FileCheck2,
  CheckCircle2,
} from 'lucide-react';
import { Page } from '@/App';

const PRODUCTS = [
  {
    icon: Car,
    title: 'Vehicle Insurance',
    description:
      'Comprehensive cover for your car, bakkie or motorcycle with fair, sum-insured based pricing and cover for fitted extras.',
    image:
      'https://images.pexels.com/photos/18129619/pexels-photo-18129619.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    icon: HomeIcon,
    title: 'Home Owners & Contents',
    description:
      'Protect your building and household contents against fire, storm and theft — with fair rates for thatch and standard roofs.',
    image:
      'https://images.pexels.com/photos/7710011/pexels-photo-7710011.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    icon: Gem,
    title: 'All Risk Possessions',
    description:
      'Cover the things you carry with you — laptops, jewelry, cameras, firearms, clothing and bicycles — wherever you take them.',
    image:
      'https://images.pexels.com/photos/2453658/pexels-photo-2453658.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
];

const STEPS = [
  {
    icon: ClipboardList,
    title: 'Tell us about you',
    description: 'A few quick details — your name, mobile number and email address.',
  },
  {
    icon: Sliders,
    title: 'Build your cover',
    description: 'Add your vehicle, home, contents or valuables and answer a few rating questions.',
  },
  {
    icon: Zap,
    title: 'Get an instant quote',
    description: 'Our rating engine calculates your premium in real time, right in your browser.',
  },
  {
    icon: FileCheck2,
    title: 'Accept & get covered',
    description: 'Accept your quote and track it to policy issue from your client portal.',
  },
];

const FEATURES = [
  {
    icon: Zap,
    title: 'Instant, transparent quotes',
    description: 'See exactly how your premium is calculated — no waiting, no hidden loadings.',
  },
  {
    icon: ShieldCheck,
    title: 'Sound underwriting',
    description: 'High-value vehicles, homes and contents are automatically flagged for expert review.',
  },
  {
    icon: BadgeCheck,
    title: 'Fair, risk-based pricing',
    description: 'Rates that reflect your driver profile, roof type and the value of what you insure.',
  },
  {
    icon: Headset,
    title: 'Local support, always',
    description: 'A South African team ready to help with quotes, changes and claims.',
  },
];

export default function LandingPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  return (
    <div>
      <section className="relative overflow-hidden bg-navy-950">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/34598588/pexels-photo-34598588.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
            alt="Colourful South African neighbourhood street"
            className="h-full w-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/90 to-navy-950/50" />
        </div>

        <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:px-8">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-teal-500/10 px-3 py-1 text-sm font-medium text-teal-300 ring-1 ring-inset ring-teal-500/30">
              <ShieldCheck className="h-4 w-4" />
              South African Short-Term Insurance
            </span>
            <h1 className="mt-6 text-4xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl lg:text-6xl">
              Cover that fits your life,
              <span className="text-teal-400"> priced fairly</span>
            </h1>
            <p className="mt-6 text-lg leading-relaxed text-slate-300">
              Insure your vehicle, home, contents and valuables with a quote calculated instantly
              and transparently — no call centres, no waiting.
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-4">
              <button
                onClick={() => onNavigate('quote')}
                className="inline-flex items-center gap-2 rounded-md bg-teal-500 px-6 py-3.5 text-base font-semibold text-navy-950 shadow-lg shadow-teal-500/20 transition-all hover:bg-teal-400 hover:shadow-teal-400/30"
              >
                Get Your Free Quote
                <ArrowRight className="h-5 w-5" />
              </button>
              <button
                onClick={() => onNavigate('portal')}
                className="inline-flex items-center gap-2 rounded-md border border-white/20 px-6 py-3.5 text-base font-semibold text-white transition-colors hover:bg-white/10"
              >
                Client Portal
              </button>
            </div>

            <dl className="mt-14 grid grid-cols-3 gap-6 border-t border-white/10 pt-8">
              <div>
                <dt className="text-2xl font-bold text-white sm:text-3xl">2 min</dt>
                <dd className="mt-1 text-sm text-slate-400">To your first quote</dd>
              </div>
              <div>
                <dt className="text-2xl font-bold text-white sm:text-3xl">4</dt>
                <dd className="mt-1 text-sm text-slate-400">Cover types in one place</dd>
              </div>
              <div>
                <dt className="text-2xl font-bold text-white sm:text-3xl">24/7</dt>
                <dd className="mt-1 text-sm text-slate-400">Portal access</dd>
              </div>
            </dl>
          </div>
        </div>
      </section>

      <section className="bg-white py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-teal-600">What we cover</h2>
            <p className="mt-2 text-3xl font-bold tracking-tight text-navy-900 sm:text-4xl">
              Insurance built around what matters to you
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 gap-8 md:grid-cols-3">
            {PRODUCTS.map((product) => (
              <div
                key={product.title}
                className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.title}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-950/60 to-transparent" />
                  <span className="absolute bottom-4 left-4 flex h-11 w-11 items-center justify-center rounded-lg bg-white shadow-md">
                    <product.icon className="h-5 w-5 text-teal-600" />
                  </span>
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-bold text-navy-900">{product.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">{product.description}</p>
                  <button
                    onClick={() => onNavigate('quote')}
                    className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-teal-600 transition-colors hover:text-teal-700"
                  >
                    Get a quote <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-teal-600">How it works</h2>
            <p className="mt-2 text-3xl font-bold tracking-tight text-navy-900 sm:text-4xl">
              From details to cover in four steps
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((step, index) => (
              <div key={step.title} className="relative rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-100">
                <span className="text-sm font-bold text-teal-600">Step {index + 1}</span>
                <div className="mt-3 flex h-12 w-12 items-center justify-center rounded-xl bg-navy-900">
                  <step.icon className="h-6 w-6 text-teal-400" />
                </div>
                <h3 className="mt-4 text-base font-bold text-navy-900">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-14 lg:grid-cols-2 lg:items-center">
            <div>
              <h2 className="text-sm font-semibold uppercase tracking-wide text-teal-600">Why Feature Insurance</h2>
              <p className="mt-2 text-3xl font-bold tracking-tight text-navy-900 sm:text-4xl">
                Insurance that respects your time and your risk profile
              </p>
              <div className="mt-10 grid grid-cols-1 gap-8 sm:grid-cols-2">
                {FEATURES.map((feature) => (
                  <div key={feature.title} className="flex gap-4">
                    <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-lg bg-teal-50">
                      <feature.icon className="h-5 w-5 text-teal-600" />
                    </span>
                    <div>
                      <h3 className="text-base font-bold text-navy-900">{feature.title}</h3>
                      <p className="mt-1 text-sm leading-relaxed text-slate-600">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <img
                src="https://images.pexels.com/photos/38474752/pexels-photo-38474752.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Family enjoying time by their car"
                className="aspect-[4/5] w-full rounded-2xl object-cover shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 hidden rounded-xl bg-white p-5 shadow-lg ring-1 ring-slate-100 sm:block">
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-50">
                    <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                  </span>
                  <div>
                    <p className="text-sm font-bold text-navy-900">Quote Accepted</p>
                    <p className="text-xs text-slate-500">Vehicle + Contents cover</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-navy-900 py-16 sm:py-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white sm:text-4xl">Ready to see your premium?</h2>
          <p className="mt-4 text-lg text-slate-300">
            Answer a few questions and get an instant, itemised quote for your vehicle, home and valuables.
          </p>
          <button
            onClick={() => onNavigate('quote')}
            className="mt-8 inline-flex items-center gap-2 rounded-md bg-teal-500 px-7 py-3.5 text-base font-semibold text-navy-950 shadow-lg shadow-teal-500/20 transition-all hover:bg-teal-400"
          >
            Start My Quote
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </section>
    </div>
  );
}
