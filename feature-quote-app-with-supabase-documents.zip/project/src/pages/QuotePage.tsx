import { useMemo, useState } from 'react';
import {
  CheckCircle2,
  ArrowLeft,
  ArrowRight,
  AlertTriangle,
  Tag,
  RotateCcw,
  Save,
  Loader2,
  FileText,
  Car,
  Home as HomeIcon,
  Gem,
  ShieldCheck,
  Ship,
  Truck,
} from 'lucide-react';
import {
  AllRiskItem,
  ClientDetails,
  HomeInput,
  Quote,
  VehicleInput,
  LiabilityInput,
  PleasureCraftInput,
  TrailerInput,
} from '@/types/insurance';
import { calculateQuote } from '@/lib/rating';
import { formatCurrency } from '@/lib/format';
import { createQuote, findOrCreateClient } from '@/lib/api';
import WizardProgress from '@/components/quote/WizardProgress';
import OnboardingStep from '@/components/quote/OnboardingStep';
import SectionSelectStep, { SectionSelection } from '@/components/quote/SectionSelectStep';
import VehicleStep from '@/components/quote/VehicleStep';
import HomeStep from '@/components/quote/HomeStep';
import AllRiskStep from '@/components/quote/AllRiskStep';
import SpecialCoverStep from '@/components/quote/SpecialCoverStep';

const EMPTY_CLIENT: ClientDetails = { fullName: '', mobile: '', email: '' };

const EMPTY_SELECTION: SectionSelection = {
  vehicle: false,
  home: false,
  allRisk: false,
  liability: false,
  pleasureCraft: false,
  trailer: false,
};

const EMPTY_VEHICLE: VehicleInput = {
  included: false,
  make: '',
  model: '',
  year: '',
  sumInsured: 0,
  retailValue: 0,
  extrasValue: 0,
  driverAge: 0,
  licenseCode: 'B',
};

const EMPTY_HOME: HomeInput = {
  includeBuilding: false,
  includeContents: false,
  buildingSumInsured: 0,
  contentsSumInsured: 0,
  thatchRoof: false,
};

const EMPTY_ALL_RISK: AllRiskItem[] = [];

const EMPTY_LIABILITY: LiabilityInput = {
  included: false,
  liabilityType: 'public',
  limit: 5000000,
};

const EMPTY_PLEASURE_CRAFT: PleasureCraftInput = {
  included: false,
  year: '',
  make: '',
  model: '',
  sumInsured: 0,
  engineType: '',
  engineManufacturer: '',
  engineSize: '',
  hullType: '',
  hullMaterial: '',
};

const EMPTY_TRAILER: TrailerInput = {
  included: false,
  trailerType: 'trailer',
  year: '',
  make: '',
  model: '',
  sumInsured: 0,
  coverType: 'comprehensive',
};

const SECTION_LABELS: Record<keyof SectionSelection, string> = {
  vehicle: 'Vehicle',
  home: 'Home',
  allRisk: 'All Risk',
  liability: 'Liability',
  pleasureCraft: 'Pleasure Craft',
  trailer: 'Trailer / Caravan',
};

export default function QuotePage() {
  const [step, setStep] = useState(0);
  const [client, setClient] = useState<ClientDetails>(EMPTY_CLIENT);
  const [selection, setSelection] = useState<SectionSelection>(EMPTY_SELECTION);
  const [vehicle, setVehicle] = useState<VehicleInput>(EMPTY_VEHICLE);
  const [home, setHome] = useState<HomeInput>(EMPTY_HOME);
  const [allRisk, setAllRisk] = useState<AllRiskItem[]>(EMPTY_ALL_RISK);
  const [liability, setLiability] = useState<LiabilityInput>(EMPTY_LIABILITY);
  const [pleasureCraft, setPleasureCraft] = useState<PleasureCraftInput>(EMPTY_PLEASURE_CRAFT);
  const [trailer, setTruck] = useState<TrailerInput>(EMPTY_TRAILER);
  const [savedQuote, setSavedQuote] = useState<Quote | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const activeSections = useMemo(
    () => (Object.keys(SECTION_LABELS) as (keyof SectionSelection)[]).filter((key) => selection[key]),
    [selection],
  );

  const activeSteps = useMemo(
    () => ['Your Details', 'Select Cover', ...activeSections.map((key) => SECTION_LABELS[key]), 'Review'],
    [activeSections],
  );

  const reviewIndex = activeSteps.length - 1;

  const calculation = useMemo(
    () =>
      calculateQuote(
        selection.vehicle ? vehicle : null,
        selection.home ? home : null,
        selection.allRisk ? allRisk : null,
        selection.liability ? liability : null,
        selection.pleasureCraft ? pleasureCraft : null,
        selection.trailer ? trailer : null,
      ),
    [selection, vehicle, home, allRisk, liability, pleasureCraft, trailer],
  );

  const handleSelectionNext = (sel: SectionSelection) => {
    setSelection(sel);
    const nextSections = (Object.keys(SECTION_LABELS) as (keyof SectionSelection)[]).filter((key) => sel[key]);
    setStep(nextSections.length > 0 ? 2 : 2);
  };

  const sectionAtStep = step >= 2 && step < reviewIndex ? activeSections[step - 2] : undefined;

  const goBackFromSection = () => {
    setStep(Math.max(1, step - 1));
  };

  const handleSave = async () => {
    setSaving(true);
    setError('');
    try {
      const clientRecord = await findOrCreateClient(client);
      const quote = await createQuote({
        clientId: clientRecord.id,
        status: calculation.status,
        vehicleSection: selection.vehicle ? vehicle : null,
        homeSection: selection.home ? home : null,
        allRiskSection: selection.allRisk ? allRisk : null,
        liabilitySection: selection.liability ? liability : null,
        pleasureCraftSection: selection.pleasureCraft ? pleasureCraft : null,
        trailerSection: selection.trailer ? trailer : null,
        premiumBreakdown: calculation.breakdown,
        totalMonthlyPremium: calculation.breakdown.total,
        tags: calculation.tags,
        referralReasons: calculation.referralReasons,
      });
      setSavedQuote(quote);
      setStep(reviewIndex + 1);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save your quote. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const restart = () => {
    setStep(0);
    setClient(EMPTY_CLIENT);
    setSelection(EMPTY_SELECTION);
    setVehicle(EMPTY_VEHICLE);
    setHome(EMPTY_HOME);
    setAllRisk(EMPTY_ALL_RISK);
    setLiability(EMPTY_LIABILITY);
    setPleasureCraft(EMPTY_PLEASURE_CRAFT);
    setTrailer(EMPTY_TRAILER);
    setSavedQuote(null);
    setError('');
  };

  return (
    <div className="bg-slate-50 py-10 sm:py-16">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold tracking-tight text-navy-900 sm:text-4xl">Get Your Quote</h1>
          <p className="mt-2 text-sm text-slate-600">
            Build your cover step by step and see your premium calculated instantly.
          </p>
        </div>

        <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200 sm:p-8">
          {step <= reviewIndex && (
            <WizardProgress steps={activeSteps} currentIndex={Math.min(step, activeSteps.length - 1)} />
          )}

          {step === 0 && (
            <OnboardingStep initialValue={client} onNext={(details) => { setClient(details); setStep(1); }} />
          )}

          {step === 1 && (
            <SectionSelectStep
              initialValue={selection}
              onNext={handleSelectionNext}
              onBack={() => setStep(0)}
            />
          )}

          {sectionAtStep === 'vehicle' && (
            <VehicleStep
              initialValue={vehicle}
              onNext={(input) => { setVehicle(input); setStep(step + 1); }}
              onBack={goBackFromSection}
            />
          )}

          {sectionAtStep === 'home' && (
            <HomeStep
              initialValue={home}
              onNext={(input) => { setHome(input); setStep(step + 1); }}
              onBack={goBackFromSection}
            />
          )}

          {sectionAtStep === 'allRisk' && (
            <AllRiskStep
              initialValue={allRisk}
              onNext={(items) => { setAllRisk(items); setStep(step + 1); }}
              onBack={goBackFromSection}
            />
          )}

          {sectionAtStep === 'liability' && (
            <SpecialCoverStep
              kind="liability"
              initialValue={liability}
              onNext={(input) => { setLiability(input as LiabilityInput); setStep(step + 1); }}
              onBack={goBackFromSection}
            />
          )}

          {sectionAtStep === 'pleasureCraft' && (
            <SpecialCoverStep
              kind="pleasureCraft"
              initialValue={pleasureCraft}
              onNext={(input) => { setPleasureCraft(input as PleasureCraftInput); setStep(step + 1); }}
              onBack={goBackFromSection}
            />
          )}

          {sectionAtStep === 'trailer' && (
            <SpecialCoverStep
              kind="trailer"
              initialValue={trailer}
              onNext={(input) => { setTrailer(input as TrailerInput); setStep(step + 1); }}
              onBack={goBackFromSection}
            />
          )}

          {step === reviewIndex && !savedQuote && (
            <ReviewStep
              client={client}
              selection={selection}
              vehicle={vehicle}
              home={home}
              allRisk={allRisk}
              liability={liability}
              pleasureCraft={pleasureCraft}
              trailer={trailer}
              calculation={calculation}
              saving={saving}
              error={error}
              onBack={() => setStep(Math.max(1, reviewIndex - 1))}
              onSave={handleSave}
            />
          )}

          {step === reviewIndex + 1 && savedQuote && (
            <SuccessStep quote={savedQuote} onRestart={restart} />
          )}
        </div>
      </div>
    </div>
  );
}

interface ReviewStepProps {
  client: ClientDetails;
  selection: SectionSelection;
  vehicle: VehicleInput;
  home: HomeInput;
  allRisk: AllRiskItem[];
  liability: LiabilityInput;
  pleasureCraft: PleasureCraftInput;
  trailer: TrailerInput;
  calculation: ReturnType<typeof calculateQuote>;
  saving: boolean;
  error: string;
  onBack: () => void;
  onSave: () => void;
}

function ReviewStep({
  client,
  selection,
  vehicle,
  home,
  allRisk,
  liability,
  pleasureCraft,
  trailer,
  calculation,
  saving,
  error,
  onBack,
  onSave,
}: ReviewStepProps) {
  const isReferred = calculation.referralReasons.length > 0;

  return (
    <div>
      <h2 className="text-2xl font-bold text-navy-900">Your Quote Summary</h2>
      <p className="mt-2 text-sm text-slate-600">
        Review your cover and premium below. {client.fullName.split(' ')[0]}, your details are ready to save.
      </p>

      <div className="mt-6 rounded-lg bg-slate-50 p-4 ring-1 ring-slate-200">
        <h3 className="text-sm font-semibold text-slate-700">Client Details</h3>
        <dl className="mt-3 grid grid-cols-1 gap-2 text-sm sm:grid-cols-3">
          <div><dt className="text-xs text-slate-400">Name</dt><dd className="font-medium text-navy-900">{client.fullName}</dd></div>
          <div><dt className="text-xs text-slate-400">Mobile</dt><dd className="font-medium text-navy-900">{client.mobile}</dd></div>
          <div><dt className="text-xs text-slate-400">Email</dt><dd className="font-medium text-navy-900">{client.email}</dd></div>
        </dl>
      </div>

      <div className="mt-4 space-y-3">
        {selection.vehicle && calculation.vehicle && (
          <SectionCard
            icon={Car}
            title="Vehicle"
            subtitle={`${vehicle.make} ${vehicle.model} ${vehicle.year}`.trim()}
            rows={[
              { label: 'Sum insured', value: formatCurrency(vehicle.sumInsured) },
              { label: 'Retail value', value: formatCurrency(vehicle.retailValue) },
              { label: 'Extras value', value: formatCurrency(vehicle.extrasValue) },
              { label: 'Effective rate', value: `${(calculation.vehicle.effectiveRatePct * 100).toFixed(3)}% / month` },
              ...(calculation.vehicle.minimumApplied ? [{ label: 'Note', value: 'Minimum premium of R250 applied' }] : []),
            ]}
            premium={calculation.vehicle.totalPremium}
          />
        )}

        {selection.home && calculation.home && (
          <SectionCard
            icon={HomeIcon}
            title="Home & Contents"
            subtitle={home.thatchRoof ? 'Thatch roof property' : 'Standard roof property'}
            rows={[
              ...(home.includeBuilding ? [{ label: 'Building sum insured', value: formatCurrency(home.buildingSumInsured) }] : []),
              ...(home.includeContents ? [{ label: 'Contents (rated)', value: formatCurrency(calculation.home.ratedContentsSumInsured) }] : []),
            ]}
            premium={calculation.home.totalPremium}
          />
        )}

        {selection.allRisk && calculation.allRisk && (
          <SectionCard
            icon={Gem}
            title="All Risk / Valuables"
            subtitle={`${calculation.allRisk.items.length} item${calculation.allRisk.items.length === 1 ? '' : 's'}`}
            rows={calculation.allRisk.items.map((item) => ({
              label: item.description,
              value: `${formatCurrency(item.value)} @ ${(item.ratePct * 100).toFixed(1)}%`,
            }))}
            premium={calculation.allRisk.totalPremium}
          />
        )}

        {selection.liability && calculation.liability && (
          <SectionCard
            icon={ShieldCheck}
            title="Liability"
            subtitle={liability.liabilityType.replace('_', ' ')}
            rows={[
              { label: 'Requested limit', value: formatCurrency(liability.limit) },
              { label: 'Rating', value: 'Underwriter confirmation required' },
            ]}
            premium={calculation.liability.premium}
            premiumLabel="Under review"
          />
        )}

        {selection.pleasureCraft && calculation.pleasureCraft && (
          <SectionCard
            icon={Ship}
            title="Pleasure Craft"
            subtitle={`${pleasureCraft.make} ${pleasureCraft.model} ${pleasureCraft.year}`.trim()}
            rows={[
              { label: 'Sum insured', value: formatCurrency(pleasureCraft.sumInsured) },
              {
                label: 'Indicative range',
                value: `${formatCurrency(calculation.pleasureCraft.indicativeMinPremium)}–${formatCurrency(calculation.pleasureCraft.indicativeMaxPremium)}/mo`,
              },
            ]}
            premium={calculation.pleasureCraft.premium}
            premiumLabel="Under review"
          />
        )}

        {selection.trailer && calculation.trailer && (
          <SectionCard
            icon={Truck}
            title="Trailer / Caravan"
            subtitle={`${trailer.trailerType} · ${trailer.make} ${trailer.model} ${trailer.year}`.trim()}
            rows={[
              { label: 'Sum insured', value: formatCurrency(trailer.sumInsured) },
              ...(trailer.coverType === 'third_party_only'
                ? [{ label: 'Cover', value: 'Third Party Only' }]
                : [{
                    label: 'Indicative range',
                    value: `${formatCurrency(calculation.trailer.indicativeMinPremium)}–${formatCurrency(calculation.trailer.indicativeMaxPremium)}/mo`,
                  }]),
            ]}
            premium={calculation.trailer.premium}
            premiumLabel={trailer.coverType === 'third_party_only' ? undefined : 'Under review'}
          />
        )}
      </div>

      {calculation.tags.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {calculation.tags.map((tag) => (
            <span key={tag} className="inline-flex items-center gap-1.5 rounded-full bg-teal-50 px-3 py-1 text-xs font-semibold text-teal-700 ring-1 ring-inset ring-teal-200">
              <Tag className="h-3 w-3" /> {tag}
            </span>
          ))}
        </div>
      )}

      <div className="mt-6 rounded-xl bg-navy-950 p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-300">{isReferred ? "Known Monthly Premium (before referred sections)" : "Total Monthly Premium"}</p>
            <p className="mt-1 text-3xl font-bold">{formatCurrency(calculation.breakdown.total)}</p>
          </div>
          <FileText className="h-10 w-10 text-teal-400" />
        </div>
      </div>

      {isReferred && (
        <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 flex-shrink-0 text-amber-600" />
            <div>
              <p className="text-sm font-semibold text-amber-900">Underwriting Referral Required</p>
              <ul className="mt-1.5 list-inside list-disc text-sm text-amber-800">
                {calculation.referralReasons.map((reason) => (
                  <li key={reason}>{reason}</li>
                ))}
              </ul>
              <p className="mt-2 text-sm text-amber-700">
                Your quote will be saved with a "Referred" status. Our underwriting team will review it before it can be accepted.
              </p>
            </div>
          </div>
        </div>
      )}

      {error && <p className="mt-4 text-sm text-red-600">{error}</p>}

      <div className="mt-8 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          disabled={saving}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 hover:text-navy-900 disabled:opacity-50"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <button
          type="button"
          onClick={onSave}
          disabled={saving}
          className="inline-flex items-center gap-2 rounded-md bg-teal-600 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-500 disabled:opacity-50"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {saving ? 'Saving...' : 'Save Quote'}
        </button>
      </div>
    </div>
  );
}

interface SectionCardProps {
  icon: typeof Car;
  title: string;
  subtitle: string;
  rows: { label: string; value: string }[];
  premium: number;
  premiumLabel?: string;
}

function SectionCard({ icon: Icon, title, subtitle, rows, premium, premiumLabel }: SectionCardProps) {
  return (
    <div className="rounded-lg border border-slate-200 p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-navy-100">
            <Icon className="h-4 w-4 text-navy-700" />
          </span>
          <div>
            <h4 className="text-sm font-bold text-navy-900">{title}</h4>
            <p className="text-xs text-slate-500">{subtitle}</p>
          </div>
        </div>
        <span className="text-sm font-bold text-navy-900">{premiumLabel ?? `${formatCurrency(premium)}/mo`}</span>
      </div>
      {rows.length > 0 && (
        <dl className="mt-3 grid grid-cols-1 gap-x-6 gap-y-1.5 text-xs sm:grid-cols-2">
          {rows.map((row, i) => (
            <div key={i} className="flex justify-between">
              <dt className="text-slate-500">{row.label}</dt>
              <dd className="font-medium text-slate-700">{row.value}</dd>
            </div>
          ))}
        </dl>
      )}
    </div>
  );
}

function SuccessStep({ quote, onRestart }: { quote: Quote; onRestart: () => void }) {
  return (
    <div className="text-center">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50">
        <CheckCircle2 className="h-8 w-8 text-emerald-600" />
      </div>
      <h2 className="mt-6 text-2xl font-bold text-navy-900">Quote Saved Successfully</h2>
      <p className="mt-2 text-sm text-slate-600">
        Your quote reference is
      </p>
      <p className="mt-1 text-lg font-bold text-teal-600">{quote.quote_number}</p>
      <p className="mt-4 text-sm text-slate-600">
        {quote.status === 'referred'
          ? 'Your quote has been referred to our underwriting team. You can track its progress in the Client Portal.'
          : 'You can accept this quote and track its progress in the Client Portal.'}
      </p>
      <button
        type="button"
        onClick={onRestart}
        className="mt-8 inline-flex items-center gap-2 rounded-md border border-slate-300 px-5 py-2.5 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-50"
      >
        <RotateCcw className="h-4 w-4" /> Start a New Quote
      </button>
    </div>
  );
}
