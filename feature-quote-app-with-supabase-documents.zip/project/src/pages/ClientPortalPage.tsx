import { useEffect, useMemo, useState } from 'react';
import {
  Phone,
  Lock,
  Loader2,
  ArrowRight,
  ShieldCheck,
  FileText,
  CheckCircle2,
  AlertCircle,
  Clock,
  LogOut,
  RotateCw,
} from 'lucide-react';
import { QuoteWithClient } from '@/types/insurance';
import { fetchQuotesByMobile, updateQuoteStatus } from '@/lib/api';
import { formatCurrency, formatDate } from '@/lib/format';
import StatusBadge from '@/components/shared/StatusBadge';
import DocumentCentre from '@/components/documents/DocumentCentre';

const MOBILE_REGEX = /^(\+27|0)[6-8][0-9]{8}$/;
const STORAGE_KEY = 'fi_portal_mobile';

type Phase = 'login' | 'otp' | 'dashboard';

export default function ClientPortalPage() {
  const [phase, setPhase] = useState<Phase>('login');
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const [quotes, setQuotes] = useState<QuoteWithClient[]>([]);
  const [loadError, setLoadError] = useState('');
  const [acting, setActing] = useState<string | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored && MOBILE_REGEX.test(stored)) {
      setMobile(stored);
      setPhase('dashboard');
    }
  }, []);

  const sendOtp = (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!MOBILE_REGEX.test(mobile.trim())) {
      setError('Enter a valid South African mobile number, e.g. 082 123 4567.');
      return;
    }
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);
    setPhase('otp');
  };

  const verifyOtp = (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (otp.trim() !== generatedOtp) {
      setError('The OTP you entered is incorrect. Please try again.');
      return;
    }
    setLoading(true);
    loadDashboard(mobile.trim());
  };

  const loadDashboard = async (number: string) => {
    try {
      const data = await fetchQuotesByMobile(number);
      setQuotes(data);
      localStorage.setItem(STORAGE_KEY, number);
      setPhase('dashboard');
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not load your quotes.');
    } finally {
      setLoading(false);
    }
  };

  const signOut = () => {
    localStorage.removeItem(STORAGE_KEY);
    setPhase('login');
    setMobile('');
    setOtp('');
    setGeneratedOtp('');
    setQuotes([]);
    setError('');
    setLoadError('');
  };

  const acceptQuote = async (quoteId: string) => {
    setActing(quoteId);
    try {
      await updateQuoteStatus(quoteId, 'accepted');
      setQuotes((prev) =>
        prev.map((q) => (q.id === quoteId ? { ...q, status: 'accepted' } : q)),
      );
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not accept this quote.');
    } finally {
      setActing(null);
    }
  };

  const stats = useMemo(() => {
    const total = quotes.length;
    const accepted = quotes.filter((q) => q.status === 'accepted').length;
    const referred = quotes.filter((q) => q.status === 'referred').length;
    const issued = quotes.filter((q) => q.status === 'issued').length;
    return { total, accepted, referred, issued };
  }, [quotes]);

  if (phase === 'login') {
    return (
      <div className="flex min-h-[calc(100vh-64px)] items-center justify-center bg-slate-50 px-4 py-12">
        <div className="w-full max-w-md">
          <div className="rounded-2xl bg-white p-8 shadow-sm ring-1 ring-slate-200">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-xl bg-navy-900">
              <ShieldCheck className="h-7 w-7 text-teal-400" />
            </div>
            <h1 className="mt-6 text-center text-2xl font-bold text-navy-900">Client Portal</h1>
            <p className="mt-2 text-center text-sm text-slate-600">
              Sign in with your mobile number to view and manage your quotes.
            </p>
            <form onSubmit={sendOtp} className="mt-8 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700">Mobile Number</label>
                <div className="mt-1.5 relative">
                  <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="tel"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    placeholder="082 123 4567"
                    className="block w-full rounded-md border border-slate-300 py-2.5 pl-10 pr-3 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>
                {error && <p className="mt-1.5 text-sm text-red-600">{error}</p>}
              </div>
              <button
                type="submit"
                className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-navy-900 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-navy-800"
              >
                Send OTP <ArrowRight className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  if (phase === 'otp') {
    return (
      <div className="flex min-h-[calc(100vh-64px)] items-center justify-center bg-slate-50 px-4 py-12">
        <div className="w-full max-w-md">
          <div className="rounded-2xl bg-white p-8 shadow-sm ring-1 ring-slate-200">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-xl bg-teal-50">
              <Lock className="h-7 w-7 text-teal-600" />
            </div>
            <h1 className="mt-6 text-center text-2xl font-bold text-navy-900">Enter Your OTP</h1>
            <p className="mt-2 text-center text-sm text-slate-600">
              We sent a one-time code to <span className="font-semibold text-navy-900">{mobile}</span>.
            </p>
            <div className="mt-4 rounded-lg bg-blue-50 px-4 py-3 text-center text-sm text-blue-800">
              <span className="font-semibold">Demo mode:</span> your code is <span className="font-mono font-bold tracking-widest">{generatedOtp}</span>
            </div>
            <form onSubmit={verifyOtp} className="mt-6 space-y-4">
              <div>
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  placeholder="123456"
                  className="mx-auto block w-48 rounded-md border border-slate-300 px-3 py-3 text-center text-lg font-bold tracking-widest focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
                {error && <p className="mt-1.5 text-center text-sm text-red-600">{error}</p>}
              </div>
              <button
                type="submit"
                disabled={loading}
                className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-teal-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-500 disabled:opacity-50"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
                {loading ? 'Verifying...' : 'Verify & Sign In'}
              </button>
              <button
                type="button"
                onClick={() => { setPhase('login'); setOtp(''); setError(''); }}
                className="w-full text-center text-sm text-slate-500 hover:text-navy-900"
              >
                Use a different number
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 py-10 sm:py-16">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-navy-900">My Quotes</h1>
            <p className="mt-1 text-sm text-slate-600">Welcome back. Manage your insurance quotes below.</p>
          </div>
          <button
            onClick={signOut}
            className="inline-flex items-center gap-2 rounded-md border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-100"
          >
            <LogOut className="h-4 w-4" /> Sign Out
          </button>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
          <StatCard label="Total Quotes" value={stats.total} icon={FileText} tone="navy" />
          <StatCard label="Accepted" value={stats.accepted} icon={CheckCircle2} tone="emerald" />
          <StatCard label="Referred" value={stats.referred} icon={AlertCircle} tone="amber" />
          <StatCard label="Issued" value={stats.issued} icon={ShieldCheck} tone="teal" />
        </div>

        {loadError && (
          <div className="mt-6 rounded-lg bg-red-50 p-4 text-sm text-red-700 ring-1 ring-red-200">
            {loadError}
          </div>
        )}

        {quotes[0]?.client?.id && (
          <div className="mt-8">
            <div className="mb-3">
              <h2 className="text-xl font-bold text-navy-900">My Documents</h2>
              <p className="text-sm text-slate-600">Upload documents we request and download documents sent to you by Feature.</p>
            </div>
            <DocumentCentre clientId={quotes[0].client.id} />
          </div>
        )}

        <div className="mt-8 space-y-4">
          {quotes.length === 0 ? (
            <div className="rounded-2xl bg-white p-12 text-center shadow-sm ring-1 ring-slate-200">
              <FileText className="mx-auto h-12 w-12 text-slate-300" />
              <h3 className="mt-4 text-lg font-semibold text-navy-900">No quotes yet</h3>
              <p className="mt-1 text-sm text-slate-600">
                Once you complete a quote, it will appear here.
              </p>
            </div>
          ) : (
            quotes.map((quote) => (
              <QuoteCard
                key={quote.id}
                quote={quote}
                acting={acting === quote.id}
                onAccept={() => acceptQuote(quote.id)}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}

const TONE_CLASSES: Record<string, string> = {
  navy: 'bg-navy-100 text-navy-700',
  emerald: 'bg-emerald-100 text-emerald-700',
  amber: 'bg-amber-100 text-amber-700',
  teal: 'bg-teal-100 text-teal-700',
};

function StatCard({ label, value, icon: Icon, tone }: { label: string; value: number; icon: typeof FileText; tone: string }) {
  return (
    <div className="rounded-xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
      <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${TONE_CLASSES[tone]}`}>
        <Icon className="h-5 w-5" />
      </div>
      <p className="mt-3 text-2xl font-bold text-navy-900">{value}</p>
      <p className="text-xs font-medium text-slate-500">{label}</p>
    </div>
  );
}

function QuoteCard({ quote, acting, onAccept }: { quote: QuoteWithClient; acting: boolean; onAccept: () => void }) {
  const canAccept = quote.status === 'quoted';
  return (
    <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h3 className="text-base font-bold text-navy-900">{quote.quote_number}</h3>
            <StatusBadge status={quote.status} />
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
            <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {formatDate(quote.created_at)}</span>
            {quote.tags.map((tag) => (
              <span key={tag} className="rounded-full bg-teal-50 px-2 py-0.5 font-semibold text-teal-700">{tag}</span>
            ))}
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-slate-500">Monthly Premium</p>
          <p className="text-xl font-bold text-navy-900">{formatCurrency(Number(quote.total_monthly_premium))}</p>
        </div>
      </div>

      {quote.referral_reasons.length > 0 && (
        <div className="mt-4 rounded-lg bg-amber-50 p-3 text-xs text-amber-800 ring-1 ring-amber-200">
          <span className="font-semibold">Referred:</span> {quote.referral_reasons.join('; ')}
        </div>
      )}

      {canAccept && (
        <div className="mt-4 flex justify-end">
          <button
            onClick={onAccept}
            disabled={acting}
            className="inline-flex items-center gap-2 rounded-md bg-teal-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-teal-500 disabled:opacity-50"
          >
            {acting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
            {acting ? 'Accepting...' : 'Accept Quote'}
          </button>
        </div>
      )}

      {quote.status === 'accepted' && (
        <p className="mt-4 flex items-center gap-1.5 text-xs font-medium text-emerald-700">
          <CheckCircle2 className="h-4 w-4" /> Quote accepted — awaiting policy issue.
        </p>
      )}
      {quote.status === 'issued' && (
        <p className="mt-4 flex items-center gap-1.5 text-xs font-medium text-emerald-700">
          <ShieldCheck className="h-4 w-4" /> Policy issued. You're covered.
        </p>
      )}
      {quote.status === 'referred' && (
        <p className="mt-4 flex items-center gap-1.5 text-xs font-medium text-amber-700">
          <AlertCircle className="h-4 w-4" /> Our underwriting team is reviewing this quote.
        </p>
      )}
    </div>
  );
}
