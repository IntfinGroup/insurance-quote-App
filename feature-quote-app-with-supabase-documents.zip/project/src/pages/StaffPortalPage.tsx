import { useEffect, useMemo, useState } from 'react';
import {
  Loader2,
  Search,
  Sliders,
  FileText,
  Users,
  TrendingUp,
  RefreshCw,
  ShieldAlert,
  History,
  X,
  Save,
  AlertTriangle,
} from 'lucide-react';
import { QuoteStatus, QuoteWithClient, VehicleInput, HomeInput, AllRiskItem } from '@/types/insurance';
import {
  applyAdminOverride,
  fetchAllQuotes,
  fetchAuditLog,
  insertAuditLog,
  updateQuoteSections,
} from '@/lib/api';
import { calculateQuote } from '@/lib/rating';
import { formatCurrency, formatDate, formatDateTime } from '@/lib/format';
import StatusBadge from '@/components/shared/StatusBadge';
import DocumentCentre from '@/components/documents/DocumentCentre';

const STATUS_FILTERS: (QuoteStatus | 'all')[] = ['all', 'draft', 'quoted', 'referred', 'accepted', 'issued'];

export default function StaffPortalPage() {
  const [quotes, setQuotes] = useState<QuoteWithClient[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<QuoteStatus | 'all'>('all');
  const [selected, setSelected] = useState<QuoteWithClient | null>(null);

  const loadQuotes = async () => {
    setLoading(true);
    setLoadError('');
    try {
      const data = await fetchAllQuotes();
      setQuotes(data);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not load quotes.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadQuotes();
  }, []);

  const filtered = useMemo(() => {
    return quotes.filter((q) => {
      if (statusFilter !== 'all' && q.status !== statusFilter) return false;
      if (search.trim()) {
        const term = search.toLowerCase();
        const haystack = `${q.quote_number} ${q.client?.full_name ?? ''} ${q.client?.mobile ?? ''} ${q.client?.email ?? ''}`.toLowerCase();
        if (!haystack.includes(term)) return false;
      }
      return true;
    });
  }, [quotes, statusFilter, search]);

  const stats = useMemo(() => {
    const total = quotes.length;
    const referred = quotes.filter((q) => q.status === 'referred').length;
    const accepted = quotes.filter((q) => q.status === 'accepted').length;
    const issued = quotes.filter((q) => q.status === 'issued').length;
    const totalPremium = quotes.reduce((sum, q) => sum + Number(q.total_monthly_premium), 0);
    return { total, referred, accepted, issued, totalPremium };
  }, [quotes]);

  const handleUpdated = (updated: QuoteWithClient) => {
    setQuotes((prev) => prev.map((q) => (q.id === updated.id ? { ...q, ...updated } : q)));
    setSelected((prev) => (prev ? { ...prev, ...updated } : prev));
  };

  return (
    <div className="bg-slate-50 py-10 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-navy-900">Staff Dashboard</h1>
            <p className="mt-1 text-sm text-slate-600">Manage quotes across the business, recalculate premiums and apply overrides.</p>
          </div>
          <button
            onClick={loadQuotes}
            disabled={loading}
            className="inline-flex items-center gap-2 rounded-md border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-50"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            Refresh
          </button>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard label="Total Quotes" value={String(stats.total)} icon={FileText} tone="navy" />
          <StatCard label="Awaiting Underwriting" value={String(stats.referred)} icon={ShieldAlert} tone="amber" />
          <StatCard label="Accepted" value={String(stats.accepted)} icon={Users} tone="blue" />
          <StatCard label="Premium Book /mo" value={formatCurrency(stats.totalPremium)} icon={TrendingUp} tone="teal" />
        </div>

        <div className="mt-8 rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
          <div className="border-b border-slate-200 p-4">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="relative flex-1 max-w-xs">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search quote no, name, mobile..."
                  className="block w-full rounded-md border border-slate-300 py-2 pl-10 pr-3 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
              </div>
              <div className="flex flex-wrap gap-1.5">
                {STATUS_FILTERS.map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setStatusFilter(filter)}
                    className={`rounded-md px-3 py-1.5 text-xs font-semibold capitalize transition-colors ${
                      statusFilter === filter
                        ? 'bg-navy-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {loadError && (
            <div className="p-4 text-sm text-red-700">{loadError}</div>
          )}

          {loading ? (
            <div className="flex items-center justify-center p-12">
              <Loader2 className="h-6 w-6 animate-spin text-slate-400" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="p-12 text-center">
              <FileText className="mx-auto h-10 w-10 text-slate-300" />
              <p className="mt-3 text-sm text-slate-600">No quotes match your filters.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <Th>Quote No.</Th>
                    <Th>Client</Th>
                    <Th>Status</Th>
                    <Th right>Premium /mo</Th>
                    <Th>Date</Th>
                    <Th>Actions</Th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {filtered.map((quote) => (
                    <tr key={quote.id} className="hover:bg-slate-50">
                      <td className="whitespace-nowrap px-4 py-3 text-sm font-semibold text-navy-900">{quote.quote_number}</td>
                      <td className="px-4 py-3">
                        <p className="text-sm font-medium text-navy-900">{quote.client?.full_name ?? '—'}</p>
                        <p className="text-xs text-slate-500">{quote.client?.mobile ?? ''}</p>
                      </td>
                      <td className="px-4 py-3"><StatusBadge status={quote.status} /></td>
                      <td className="whitespace-nowrap px-4 py-3 text-right text-sm font-semibold text-navy-900">
                        {formatCurrency(Number(quote.total_monthly_premium))}
                        {quote.admin_override && (
                          <span className="ml-1.5 inline-block rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700">OVR</span>
                        )}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-sm text-slate-500">{formatDate(quote.created_at)}</td>
                      <td className="whitespace-nowrap px-4 py-3">
                        <button
                          onClick={() => setSelected(quote)}
                          className="inline-flex items-center gap-1.5 rounded-md bg-navy-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-navy-800"
                        >
                          <Sliders className="h-3.5 w-3.5" /> Manage
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {selected && (
        <QuoteDetailDrawer
          quote={selected}
          onClose={() => setSelected(null)}
          onUpdated={handleUpdated}
        />
      )}
    </div>
  );
}

function Th({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return (
    <th className={`px-4 py-3 text-xs font-semibold uppercase tracking-wide text-slate-500 ${right ? 'text-right' : 'text-left'}`}>
      {children}
    </th>
  );
}

const TONE_CLASSES: Record<string, string> = {
  navy: 'bg-navy-100 text-navy-700',
  amber: 'bg-amber-100 text-amber-700',
  blue: 'bg-blue-100 text-blue-700',
  teal: 'bg-teal-100 text-teal-700',
};

function StatCard({ label, value, icon: Icon, tone }: { label: string; value: string; icon: typeof FileText; tone: string }) {
  return (
    <div className="rounded-xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
      <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${TONE_CLASSES[tone]}`}>
        <Icon className="h-5 w-5" />
      </div>
      <p className="mt-3 text-xl font-bold text-navy-900">{value}</p>
      <p className="text-xs font-medium text-slate-500">{label}</p>
    </div>
  );
}

interface DrawerProps {
  quote: QuoteWithClient;
  onClose: () => void;
  onUpdated: (quote: QuoteWithClient) => void;
}

type DrawerTab = 'details' | 'documents' | 'recalculate' | 'override' | 'audit';

function QuoteDetailDrawer({ quote, onClose, onUpdated }: DrawerProps) {
  const [tab, setTab] = useState<DrawerTab>('details');
  const [staffName, setStaffName] = useState('');
  const [auditReason, setAuditReason] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [busy, setBusy] = useState(false);

  const [overridePremium, setOverridePremium] = useState(String(quote.total_monthly_premium));
  const [overrideStatus, setOverrideStatus] = useState<QuoteStatus>(quote.status);
  const [overrideReason, setOverrideReason] = useState('');

  const [auditLog, setAuditLog] = useState<AuditEntry[]>([]);

  const loadAudit = async () => {
    try {
      const log = await fetchAuditLog(quote.id);
      setAuditLog(log as AuditEntry[]);
    } catch {
      setAuditLog([]);
    }
  };

  useEffect(() => {
    if (tab === 'audit') loadAudit();
  }, [tab]);

  const currentCalc = useMemo(
    () => calculateQuote(quote.vehicle_section, quote.home_section, quote.all_risk_section, quote.liability_section, quote.pleasure_craft_section, quote.trailer_section),
    [quote],
  );

  const handleRecalculate = async () => {
    setError('');
    setSuccess('');
    if (!staffName.trim() || !auditReason.trim()) {
      setError('Staff name and audit reason are required.');
      return;
    }
    setBusy(true);
    try {
      const oldValue = {
        premium: quote.total_monthly_premium,
        status: quote.status,
        breakdown: quote.premium_breakdown,
      };
      await updateQuoteSections(quote.id, {
        vehicleSection: quote.vehicle_section,
        homeSection: quote.home_section,
        allRiskSection: quote.all_risk_section,
        liabilitySection: quote.liability_section,
        pleasureCraftSection: quote.pleasure_craft_section,
        trailerSection: quote.trailer_section,
        premiumBreakdown: currentCalc.breakdown,
        totalMonthlyPremium: currentCalc.breakdown.total,
        tags: currentCalc.tags,
        referralReasons: currentCalc.referralReasons,
        status: currentCalc.status,
      });
      await insertAuditLog({
        quoteId: quote.id,
        staffName: staffName.trim(),
        action: 'recalculate',
        reason: auditReason.trim(),
        oldValue,
        newValue: { premium: currentCalc.breakdown.total, status: currentCalc.status, breakdown: currentCalc.breakdown },
      });
      onUpdated({
        ...quote,
        total_monthly_premium: currentCalc.breakdown.total,
        premium_breakdown: currentCalc.breakdown,
        tags: currentCalc.tags,
        referral_reasons: currentCalc.referralReasons,
        status: currentCalc.status,
      });
      setSuccess('Premium recalculated and audit log updated.');
      setAuditReason('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Recalculation failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleOverride = async () => {
    setError('');
    setSuccess('');
    if (!staffName.trim() || !overrideReason.trim()) {
      setError('Staff name and override reason are required.');
      return;
    }
    const newPremium = Number(overridePremium);
    if (Number.isNaN(newPremium) || newPremium < 0) {
      setError('Enter a valid premium amount.');
      return;
    }
    setBusy(true);
    try {
      const oldValue = { premium: quote.total_monthly_premium, status: quote.status };
      await applyAdminOverride(quote.id, newPremium, overrideStatus, overrideReason.trim());
      await insertAuditLog({
        quoteId: quote.id,
        staffName: staffName.trim(),
        action: 'admin_override',
        reason: overrideReason.trim(),
        oldValue,
        newValue: { premium: newPremium, status: overrideStatus },
      });
      onUpdated({
        ...quote,
        total_monthly_premium: newPremium,
        status: overrideStatus,
        admin_override: true,
        override_reason: overrideReason.trim(),
      });
      setSuccess('Override applied and audit log updated.');
      setOverrideReason('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Override failed.');
    } finally {
      setBusy(false);
    }
  };

  const tabs: { key: DrawerTab; label: string; icon: typeof Sliders }[] = [
    { key: 'details', label: 'Details', icon: FileText },
    { key: 'documents', label: 'Documents', icon: FileText },
    { key: 'recalculate', label: 'Recalculate', icon: RefreshCw },
    { key: 'override', label: 'Admin Override', icon: Sliders },
    { key: 'audit', label: 'Audit Log', icon: History },
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-navy-950/40" onClick={onClose} />
      <div className="relative flex h-full w-full max-w-xl flex-col bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-lg font-bold text-navy-900">{quote.quote_number}</h2>
            <p className="text-sm text-slate-500">{quote.client?.full_name} · {quote.client?.mobile}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700"><X className="h-5 w-5" /></button>
        </div>

        <div className="flex gap-1 border-b border-slate-200 px-4">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => { setTab(t.key); setError(''); setSuccess(''); }}
              className={`flex items-center gap-1.5 border-b-2 px-3 py-3 text-sm font-semibold transition-colors ${
                tab === t.key ? 'border-teal-600 text-teal-700' : 'border-transparent text-slate-500 hover:text-navy-900'
              }`}
            >
              <t.icon className="h-4 w-4" /> {t.label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-5">
          {error && <div className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-700 ring-1 ring-red-200">{error}</div>}
          {success && <div className="mb-4 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700 ring-1 ring-emerald-200">{success}</div>}

          {tab === 'details' && <DetailsTab quote={quote} calc={currentCalc} />}

          {tab === 'documents' && (
            <DocumentCentre clientId={quote.client_id} quoteId={quote.id} mode="staff" />
          )}

          {tab === 'recalculate' && (
            <div className="space-y-5">
              <div className="rounded-lg bg-slate-50 p-4 ring-1 ring-slate-200">
                <p className="text-sm text-slate-600">Current stored premium: <span className="font-bold text-navy-900">{formatCurrency(Number(quote.total_monthly_premium))}/mo</span></p>
                <p className="mt-1 text-sm text-slate-600">Recalculated premium: <span className="font-bold text-teal-700">{formatCurrency(currentCalc.breakdown.total)}/mo</span></p>
                {currentCalc.breakdown.total !== Number(quote.total_monthly_premium) && (
                  <p className="mt-2 text-xs font-medium text-amber-700">The calculated premium differs from the stored premium. Saving will update it.</p>
                )}
              </div>
              <StaffFields staffName={staffName} setStaffName={setStaffName} reason={auditReason} setReason={setAuditReason} reasonLabel="Reason for recalculation" />
              <button
                onClick={handleRecalculate}
                disabled={busy}
                className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-navy-900 px-4 py-3 text-sm font-semibold text-white hover:bg-navy-800 disabled:opacity-50"
              >
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                {busy ? 'Saving...' : 'Recalculate & Save'}
              </button>
            </div>
          )}

          {tab === 'override' && (
            <div className="space-y-5">
              {quote.admin_override && quote.override_reason && (
                <div className="flex items-start gap-2 rounded-lg bg-amber-50 p-3 text-xs text-amber-800 ring-1 ring-amber-200">
                  <AlertTriangle className="mt-0.5 h-4 w-4 flex-shrink-0" />
                  <span>This quote already has an override: "{quote.override_reason}"</span>
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-slate-700">Override Premium (R/month)</label>
                <input
                  type="number"
                  min={0}
                  value={overridePremium}
                  onChange={(e) => setOverridePremium(e.target.value)}
                  className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700">Override Status</label>
                <select
                  value={overrideStatus}
                  onChange={(e) => setOverrideStatus(e.target.value as QuoteStatus)}
                  className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                >
                  {(['draft', 'quoted', 'referred', 'accepted', 'issued'] as QuoteStatus[]).map((s) => (
                    <option key={s} value={s} className="capitalize">{s}</option>
                  ))}
                </select>
              </div>
              <StaffFields staffName={staffName} setStaffName={setStaffName} reason={overrideReason} setReason={setOverrideReason} reasonLabel="Audit reason (required)" />
              <button
                onClick={handleOverride}
                disabled={busy}
                className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-amber-600 px-4 py-3 text-sm font-semibold text-white hover:bg-amber-500 disabled:opacity-50"
              >
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                {busy ? 'Applying...' : 'Apply Override'}
              </button>
            </div>
          )}

          {tab === 'audit' && (
            <div className="space-y-3">
              {auditLog.length === 0 ? (
                <p className="text-sm text-slate-500">No audit entries for this quote yet.</p>
              ) : (
                auditLog.map((entry) => (
                  <div key={entry.id} className="rounded-lg border border-slate-200 p-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-navy-900">{entry.staff_name}</span>
                      <span className="rounded bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600">{entry.action}</span>
                    </div>
                    <p className="mt-1 text-xs text-slate-500">{formatDateTime(entry.created_at)}</p>
                    <p className="mt-2 text-sm text-slate-700">{entry.reason}</p>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function DetailsTab({ quote, calc }: { quote: QuoteWithClient; calc: ReturnType<typeof calculateQuote> }) {
  const v = quote.vehicle_section;
  const h = quote.home_section;
  const a = quote.all_risk_section;
  const l = quote.liability_section;
  const p = quote.pleasure_craft_section;
  const t = quote.trailer_section;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Field label="Status" value={<StatusBadge status={quote.status} />} />
        <Field label="Monthly Premium" value={<span className="font-bold text-navy-900">{formatCurrency(Number(quote.total_monthly_premium))}</span>} />
        <Field label="Client" value={quote.client?.full_name ?? '—'} />
        <Field label="Mobile" value={quote.client?.mobile ?? '—'} />
        <Field label="Email" value={quote.client?.email ?? '—'} />
        <Field label="Created" value={formatDate(quote.created_at)} />
      </div>

      {quote.tags.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {quote.tags.map((tag) => (
            <span key={tag} className="rounded-full bg-teal-50 px-3 py-1 text-xs font-semibold text-teal-700">{tag}</span>
          ))}
        </div>
      )}

      {quote.referral_reasons.length > 0 && (
        <div className="rounded-lg bg-amber-50 p-3 text-sm text-amber-800 ring-1 ring-amber-200">
          <span className="font-semibold">Referral reasons:</span> {quote.referral_reasons.join('; ')}
        </div>
      )}

      <div className="rounded-lg bg-slate-50 p-4 ring-1 ring-slate-200">
        <h4 className="text-sm font-semibold text-navy-900">Premium Breakdown</h4>
        <dl className="mt-3 space-y-1.5 text-sm">
          {calc.breakdown.vehicle > 0 && <BreakdownRow label="Vehicle" value={calc.breakdown.vehicle} />}
          {calc.breakdown.building > 0 && <BreakdownRow label="Building" value={calc.breakdown.building} />}
          {calc.breakdown.contents > 0 && <BreakdownRow label="Contents" value={calc.breakdown.contents} />}
          {calc.breakdown.allRisk > 0 && <BreakdownRow label="All Risk" value={calc.breakdown.allRisk} />}
          {calc.breakdown.liability > 0 && <BreakdownRow label="Liability" value={calc.breakdown.liability} />}
          {calc.breakdown.pleasureCraft > 0 && <BreakdownRow label="Pleasure Craft" value={calc.breakdown.pleasureCraft} />}
          {calc.breakdown.trailer > 0 && <BreakdownRow label="Trailer / Caravan" value={calc.breakdown.trailer} />}
          <div className="mt-2 flex justify-between border-t border-slate-200 pt-2 font-bold text-navy-900">
            <span>Total</span><span>{formatCurrency(calc.breakdown.total)}/mo</span>
          </div>
        </dl>
      </div>

      {v && (
        <Section title="Vehicle">
          <p className="text-sm text-slate-600">{v.make} {v.model} {v.year}</p>
          <p className="text-xs text-slate-500">Sum insured: {formatCurrency(v.sumInsured)} · Retail: {formatCurrency(v.retailValue)} · Driver age: {v.driverAge} · License: {v.licenseCode}</p>
        </Section>
      )}
      {h && (
        <Section title="Home & Contents">
          <p className="text-sm text-slate-600">
            {h.includeBuilding ? `Building: ${formatCurrency(h.buildingSumInsured)}` : 'No building'}
            {h.includeBuilding && h.includeContents ? ' · ' : ''}
            {h.includeContents ? `Contents: ${formatCurrency(h.contentsSumInsured)}` : 'No contents'}
            {h.thatchRoof ? ' · Thatch roof' : ''}
          </p>
        </Section>
      )}
      {l && (
        <Section title="Liability">
          <p className="text-sm text-slate-600">{l.liabilityType} · Limit: {formatCurrency(l.limit)}</p>
        </Section>
      )}
      {p && (
        <Section title="Pleasure Craft">
          <p className="text-sm text-slate-600">{p.make} {p.model} {p.year} · Sum insured: {formatCurrency(p.sumInsured)}</p>
        </Section>
      )}
      {t && (
        <Section title="Trailer / Caravan">
          <p className="text-sm text-slate-600">{t.trailerType} · {t.make} {t.model} {t.year} · Sum insured: {formatCurrency(t.sumInsured)} · {t.coverType === 'third_party_only' ? 'Third Party Only' : 'Comprehensive'}</p>
        </Section>
      )}

      {a && a.length > 0 && (
        <Section title={`All Risk (${a.length} items)`}>
          <ul className="space-y-1 text-xs text-slate-500">
            {a.map((item) => (
              <li key={item.id}>{item.description}: {formatCurrency(item.value)}</li>
            ))}
          </ul>
        </Section>
      )}
    </div>
  );
}

function StaffFields({ staffName, setStaffName, reason, setReason, reasonLabel }: {
  staffName: string; setStaffName: (v: string) => void; reason: string; setReason: (v: string) => void; reasonLabel: string;
}) {
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-slate-700">Staff Name</label>
        <input
          type="text"
          value={staffName}
          onChange={(e) => setStaffName(e.target.value)}
          placeholder="Jane Doe"
          className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700">{reasonLabel}</label>
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          rows={3}
          placeholder="Explain the reason for this change..."
          className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
        />
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <p className="text-xs font-medium text-slate-400">{label}</p>
      <div className="mt-1 text-sm text-slate-700">{value}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-slate-200 p-4">
      <h4 className="text-sm font-semibold text-navy-900">{title}</h4>
      <div className="mt-2">{children}</div>
    </div>
  );
}

function BreakdownRow({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex justify-between text-slate-600">
      <span>{label}</span><span>{formatCurrency(value)}/mo</span>
    </div>
  );
}

interface AuditEntry {
  id: string;
  staff_name: string;
  action: string;
  reason: string;
  old_value: unknown;
  new_value: unknown;
  created_at: string;
}
