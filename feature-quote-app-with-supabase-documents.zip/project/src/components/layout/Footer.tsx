import { Shield, Facebook, Twitter, Instagram, Phone, Mail, MapPin } from 'lucide-react';
import { Page } from '@/App';

export default function Footer({ onNavigate }: { onNavigate: (page: Page) => void }) {
  return (
    <footer className="bg-navy-950 text-slate-300">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2 text-white">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-teal-500/10 ring-1 ring-teal-500/30">
                <Shield className="h-5 w-5 text-teal-400" strokeWidth={2.25} />
              </span>
              <span className="text-lg font-bold">Feature Insurance</span>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-slate-400">
              Short-term insurance for South African vehicles, homes and valuables — quoted
              instantly, underwritten with care.
            </p>
            <div className="mt-5 flex gap-3">
              <a href="#" className="text-slate-400 transition-colors hover:text-teal-400" aria-label="Facebook">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 transition-colors hover:text-teal-400" aria-label="Twitter">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 transition-colors hover:text-teal-400" aria-label="Instagram">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-white">Products</h3>
            <ul className="mt-4 space-y-2.5 text-sm text-slate-400">
              <li>Vehicle Insurance</li>
              <li>Home Owners Cover</li>
              <li>House Contents</li>
              <li>All Risk / Portable Possessions</li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-white">Company</h3>
            <ul className="mt-4 space-y-2.5 text-sm text-slate-400">
              <li>
                <button onClick={() => onNavigate('quote')} className="hover:text-teal-400">
                  Get a Quote
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('portal')} className="hover:text-teal-400">
                  Client Portal
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('staff')} className="hover:text-teal-400">
                  Staff Portal
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-white">Contact</h3>
            <ul className="mt-4 space-y-3 text-sm text-slate-400">
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-teal-400" /> 0861 000 000
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-teal-400" /> support@featureinsurance.co.za
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-teal-400" /> Sandton, Johannesburg
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-white/10 pt-6 text-xs text-slate-500">
          <p>
            &copy; {new Date().getFullYear()} Feature Insurance. All rights reserved. Feature Insurance is a
            licensed short-term insurance provider operating under South African insurance regulation.
          </p>
        </div>
      </div>
    </footer>
  );
}
