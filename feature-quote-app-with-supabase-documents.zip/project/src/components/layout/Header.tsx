import { Shield, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Page } from '@/App';

interface HeaderProps {
  page: Page;
  onNavigate: (page: Page) => void;
}

const NAV_ITEMS: { page: Page; label: string }[] = [
  { page: 'landing', label: 'Home' },
  { page: 'products', label: 'Products' },
  { page: 'quote', label: 'Get a Quote' },
  { page: 'portal', label: 'Client Portal' },
  { page: 'staff', label: 'Staff Portal' },
];

export default function Header({ page, onNavigate }: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  const navigate = (target: Page) => {
    onNavigate(target);
    setMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <button
          onClick={() => navigate('landing')}
          className="flex items-center gap-2 text-slate-900"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy-900">
            <Shield className="h-5 w-5 text-teal-400" strokeWidth={2.25} />
          </span>
          <span className="text-lg font-bold tracking-tight">
            Feature <span className="text-teal-600">Insurance</span>
          </span>
        </button>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.page}
              onClick={() => navigate(item.page)}
              className={`rounded-md px-4 py-2 text-sm font-medium transition-colors ${
                page === item.page
                  ? 'bg-navy-900 text-white'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-navy-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <button
          onClick={() => navigate('quote')}
          className="hidden rounded-md bg-teal-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-teal-500 md:inline-flex"
        >
          Get a Quote
        </button>

        <button
          className="text-slate-700 md:hidden"
          onClick={() => setMenuOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {menuOpen && (
        <nav className="border-t border-slate-200 bg-white px-4 py-3 md:hidden">
          <div className="flex flex-col gap-1">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.page}
                onClick={() => navigate(item.page)}
                className={`rounded-md px-4 py-2.5 text-left text-sm font-medium ${
                  page === item.page ? 'bg-navy-900 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </nav>
      )}
    </header>
  );
}
