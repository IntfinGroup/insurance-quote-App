import { QuoteStatus } from '@/types/insurance';

const STATUS_STYLES: Record<QuoteStatus, string> = {
  draft: 'bg-slate-100 text-slate-600 ring-slate-200',
  quoted: 'bg-teal-50 text-teal-700 ring-teal-200',
  referred: 'bg-amber-50 text-amber-700 ring-amber-200',
  accepted: 'bg-blue-50 text-blue-700 ring-blue-200',
  issued: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
};

const STATUS_LABELS: Record<QuoteStatus, string> = {
  draft: 'Draft',
  quoted: 'Quoted',
  referred: 'Referred',
  accepted: 'Accepted',
  issued: 'Issued',
};

export default function StatusBadge({ status }: { status: QuoteStatus }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${STATUS_STYLES[status]}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {STATUS_LABELS[status]}
    </span>
  );
}
