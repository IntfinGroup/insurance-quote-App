import { useState } from 'react';
import { Car, Home, Gem, Ship, Truck, ShieldCheck, ArrowLeft } from 'lucide-react';

export interface SectionSelection {
  vehicle: boolean;
  home: boolean;
  allRisk: boolean;
  liability: boolean;
  pleasureCraft: boolean;
  trailer: boolean;
}

interface SectionSelectStepProps {
  initialValue: SectionSelection;
  onNext: (selection: SectionSelection) => void;
  onBack: () => void;
}

const OPTIONS: { key: keyof SectionSelection; icon: typeof Car; title: string; description: string }[] = [
  { key: 'vehicle', icon: Car, title: 'Vehicle', description: 'Comprehensive cover for a car, bakkie or motorcycle.' },
  { key: 'home', icon: Home, title: 'Home & Contents', description: 'Cover your building, contents, or both.' },
  { key: 'allRisk', icon: Gem, title: 'All Risk / Valuables', description: 'Laptops, jewelry, cameras, firearms and more.' },
  { key: 'liability', icon: ShieldCheck, title: 'Liability', description: 'Personal, public or business liability cover.' },
  { key: 'pleasureCraft', icon: Ship, title: 'Pleasure Craft', description: 'Boats and other recreational watercraft.' },
  { key: 'trailer', icon: Truck, title: 'Trailer / Caravan', description: 'Truck or caravan comprehensive / third-party cover.' },
];

export default function SectionSelectStep({ initialValue, onNext, onBack }: SectionSelectStepProps) {
  const [selection, setSelection] = useState(initialValue);

  const toggle = (key: keyof SectionSelection) => {
    setSelection((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const anySelected = Object.values(selection).some(Boolean);

  return (
    <div>
      <h2 className="text-2xl font-bold text-navy-900">What would you like to insure?</h2>
      <p className="mt-2 text-sm text-slate-600">Select one or more. You can add everything in a single quote.</p>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {OPTIONS.map((option) => {
          const active = selection[option.key];
          return (
            <button
              key={option.key}
              type="button"
              onClick={() => toggle(option.key)}
              className={`rounded-xl border-2 p-5 text-left transition-all ${
                active
                  ? 'border-teal-600 bg-teal-50 shadow-sm'
                  : 'border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              <div
                className={`flex h-11 w-11 items-center justify-center rounded-lg ${
                  active ? 'bg-teal-600' : 'bg-slate-100'
                }`}
              >
                <option.icon className={`h-5 w-5 ${active ? 'text-white' : 'text-slate-500'}`} />
              </div>
              <h3 className="mt-4 text-base font-bold text-navy-900">{option.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-600">{option.description}</p>
            </button>
          );
        })}
      </div>

      <div className="mt-8 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 hover:text-navy-900"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <button
          type="button"
          disabled={!anySelected}
          onClick={() => onNext(selection)}
          className="rounded-md bg-navy-900 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-navy-800 disabled:cursor-not-allowed disabled:bg-slate-300"
        >
          Continue
        </button>
      </div>
    </div>
  );
}
