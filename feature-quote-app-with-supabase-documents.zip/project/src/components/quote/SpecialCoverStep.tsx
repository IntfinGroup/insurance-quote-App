import { ArrowLeft, ArrowRight, ShieldCheck, Ship, Truck } from 'lucide-react';
import { useState, type ReactNode } from 'react';
import {
  LiabilityInput,
  LiabilityType,
  PleasureCraftInput,
  TrailerInput,
  TrailerType,
} from '@/types/insurance';
import { formatCurrency } from '@/lib/format';

type SpecialKind = 'liability' | 'pleasureCraft' | 'trailer';

interface Props {
  kind: SpecialKind;
  initialValue: LiabilityInput | PleasureCraftInput | TrailerInput;
  onNext: (value: LiabilityInput | PleasureCraftInput | TrailerInput) => void;
  onBack: () => void;
}

const inputClass = 'mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500';

function Field({ label, children, required = true }: { label: string; children: ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-700">
        {label}{required && <span className="text-red-500"> *</span>}
      </label>
      {children}
    </div>
  );
}

export default function SpecialCoverStep({ kind, initialValue, onNext, onBack }: Props) {
  const [value, setValue] = useState(initialValue);
  const [error, setError] = useState('');

  const title = kind === 'liability' ? 'Liability' : kind === 'pleasureCraft' ? 'Pleasure Craft' : 'Trailer / Caravan';
  const Icon = kind === 'liability' ? ShieldCheck : kind === 'pleasureCraft' ? Ship : Truck;

  const update = (patch: Record<string, unknown>) => setValue((prev) => ({ ...prev, ...patch }));

  const validate = () => {
    if (kind === 'liability') {
      const v = value as LiabilityInput;
      if (!v.limit || v.limit <= 0) return 'Please enter the liability limit.';
    }
    if (kind === 'pleasureCraft') {
      const v = value as PleasureCraftInput;
      if (!v.make.trim() || !v.model.trim() || !v.year || !v.sumInsured || v.sumInsured <= 0) {
        return 'Please complete the pleasure craft details and sum insured.';
      }
    }
    if (kind === 'trailer') {
      const v = value as TrailerInput;
      if (!v.make.trim() || !v.model.trim() || !v.year || !v.sumInsured || v.sumInsured <= 0) {
        return 'Please complete the trailer/caravan details and sum insured.';
      }
    }
    return '';
  };

  const submit = () => {
    const message = validate();
    if (message) {
      setError(message);
      return;
    }
    setError('');
    onNext(value);
  };

  return (
    <div>
      <div className="flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-50">
          <Icon className="h-5 w-5 text-teal-700" />
        </span>
        <div>
          <h2 className="text-2xl font-bold text-navy-900">{title}</h2>
          <p className="mt-1 text-sm text-slate-600">Enter the risk details required for underwriting and rating.</p>
        </div>
      </div>

      <div className="mt-8 space-y-5">
        {kind === 'liability' && (() => {
          const v = value as LiabilityInput;
          return (
            <>
              <Field label="Liability type">
                <select className={inputClass} value={v.liabilityType} onChange={(e) => update({ liabilityType: e.target.value as LiabilityType })}>
                  <option value="personal">Personal Liability</option>
                  <option value="public">Public Liability</option>
                  <option value="business">Business Liability</option>
                </select>
              </Field>
              <Field label="Requested liability limit">
                <select className={inputClass} value={v.limit} onChange={(e) => update({ limit: Number(e.target.value) })}>
                  <option value={1000000}>R1,000,000</option>
                  <option value={2000000}>R2,000,000</option>
                  <option value={5000000}>R5,000,000</option>
                  <option value={10000000}>R10,000,000</option>
                  <option value={20000000}>R20,000,000</option>
                </select>
              </Field>
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
                <strong>Underwriting note:</strong> the supplied F4M material identifies Liability/Public Liability but does not provide a complete Feature rating formula. This section will be referred rather than inventing a premium.
              </div>
            </>
          );
        })()}

        {kind === 'pleasureCraft' && (() => {
          const v = value as PleasureCraftInput;
          return (
            <>
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <Field label="Year"><input className={inputClass} type="text" value={v.year} onChange={(e) => update({ year: e.target.value })} placeholder="2020" /></Field>
                <Field label="Sum insured"><input className={inputClass} type="number" min={1} value={v.sumInsured || ''} onChange={(e) => update({ sumInsured: Number(e.target.value) })} placeholder="500000" /></Field>
                <Field label="Make"><input className={inputClass} value={v.make} onChange={(e) => update({ make: e.target.value })} placeholder="Yamaha" /></Field>
                <Field label="Model"><input className={inputClass} value={v.model} onChange={(e) => update({ model: e.target.value })} placeholder="212X" /></Field>
                <Field label="Engine type" required={false}><input className={inputClass} value={v.engineType} onChange={(e) => update({ engineType: e.target.value })} placeholder="Outboard / Inboard" /></Field>
                <Field label="Engine manufacturer" required={false}><input className={inputClass} value={v.engineManufacturer} onChange={(e) => update({ engineManufacturer: e.target.value })} placeholder="Yamaha" /></Field>
                <Field label="Engine size" required={false}><input className={inputClass} value={v.engineSize} onChange={(e) => update({ engineSize: e.target.value })} placeholder="150 HP" /></Field>
                <Field label="Hull type" required={false}><input className={inputClass} value={v.hullType} onChange={(e) => update({ hullType: e.target.value })} placeholder="Monohull" /></Field>
                <Field label="Hull material" required={false}><input className={inputClass} value={v.hullMaterial} onChange={(e) => update({ hullMaterial: e.target.value })} placeholder="Fibreglass" /></Field>
              </div>
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
                <strong>Rating note:</strong> F4M gives a 2%–4% value-based range for watercraft. The app will not choose a rate from that range automatically; the quote is referred for rate confirmation.
              </div>
            </>
          );
        })()}

        {kind === 'trailer' && (() => {
          const v = value as TrailerInput;
          return (
            <>
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <Field label="Type">
                  <select className={inputClass} value={v.trailerType} onChange={(e) => update({ trailerType: e.target.value as TrailerType })}>
                    <option value="trailer">Truck</option>
                    <option value="caravan">Caravan</option>
                  </select>
                </Field>
                <Field label="Cover type">
                  <select className={inputClass} value={v.coverType} onChange={(e) => update({ coverType: e.target.value as TrailerInput['coverType'] })}>
                    <option value="comprehensive">Comprehensive</option>
                    <option value="third_party_only">Third Party Only</option>
                  </select>
                </Field>
                <Field label="Year"><input className={inputClass} value={v.year} onChange={(e) => update({ year: e.target.value })} placeholder="2020" /></Field>
                <Field label="Sum insured"><input className={inputClass} type="number" min={1} value={v.sumInsured || ''} onChange={(e) => update({ sumInsured: Number(e.target.value) })} placeholder="150000" /></Field>
                <Field label="Make"><input className={inputClass} value={v.make} onChange={(e) => update({ make: e.target.value })} placeholder="Jurgens" /></Field>
                <Field label="Model"><input className={inputClass} value={v.model} onChange={(e) => update({ model: e.target.value })} placeholder="Fleetline" /></Field>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">
                <p><strong>Comprehensive:</strong> F4M source range is 2%–4% of value, with a noted R25 minimum.</p>
                <p className="mt-1"><strong>Third Party Only:</strong> trailer R20/month; caravan R50/month.</p>
              </div>
            </>
          );
        })()}

        {error && <p className="text-sm text-red-600">{error}</p>}

        <div className="flex items-center justify-between pt-2">
          <button type="button" onClick={onBack} className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 hover:text-navy-900">
            <ArrowLeft className="h-4 w-4" /> Back
          </button>
          <button type="button" onClick={submit} className="inline-flex items-center gap-1.5 rounded-md bg-navy-900 px-6 py-3 text-sm font-semibold text-white hover:bg-navy-800">
            Continue <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
