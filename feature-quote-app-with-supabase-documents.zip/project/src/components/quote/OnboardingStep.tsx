import { useState } from 'react';
import { ClientDetails } from '@/types/insurance';

const MOBILE_REGEX = /^(\+27|0)[6-8][0-9]{8}$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

interface OnboardingStepProps {
  initialValue: ClientDetails;
  onNext: (details: ClientDetails) => void;
}

export default function OnboardingStep({ initialValue, onNext }: OnboardingStepProps) {
  const [fullName, setFullName] = useState(initialValue.fullName);
  const [mobile, setMobile] = useState(initialValue.mobile);
  const [email, setEmail] = useState(initialValue.email);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const nextErrors: Record<string, string> = {};

    if (fullName.trim().length < 2) nextErrors.fullName = 'Please enter your full name.';
    if (!MOBILE_REGEX.test(mobile.trim())) {
      nextErrors.mobile = 'Enter a valid South African mobile number, e.g. 082 123 4567.';
    }
    if (!EMAIL_REGEX.test(email.trim())) nextErrors.email = 'Enter a valid email address.';

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    onNext({ fullName: fullName.trim(), mobile: mobile.trim(), email: email.trim() });
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-navy-900">Let's get to know you</h2>
      <p className="mt-2 text-sm text-slate-600">
        We need a few details before we can present your final quote.
      </p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-5">
        <div>
          <label className="block text-sm font-medium text-slate-700">Full Name</label>
          <input
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="Thandiwe Nkosi"
            className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
          />
          {errors.fullName && <p className="mt-1.5 text-sm text-red-600">{errors.fullName}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700">Mobile Number</label>
          <input
            type="tel"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            placeholder="082 123 4567"
            className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
          />
          {errors.mobile && <p className="mt-1.5 text-sm text-red-600">{errors.mobile}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700">Email Address</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
          />
          {errors.email && <p className="mt-1.5 text-sm text-red-600">{errors.email}</p>}
        </div>

        <button
          type="submit"
          className="mt-4 w-full rounded-md bg-navy-900 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-navy-800"
        >
          Continue
        </button>
      </form>
    </div>
  );
}
