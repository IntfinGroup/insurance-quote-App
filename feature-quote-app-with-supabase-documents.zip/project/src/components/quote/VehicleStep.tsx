import { useMemo, useState } from 'react';
import { ArrowLeft, AlertTriangle } from 'lucide-react';
import { LicenseCode, VehicleInput, LICENSE_CODE_LABELS } from '@/types/insurance';
import { calculateVehiclePremium } from '@/lib/rating';
import { formatCurrency } from '@/lib/format';

interface VehicleStepProps {
  initialValue: VehicleInput;
  onNext: (input: VehicleInput) => void;
  onBack: () => void;
}

const LICENSE_CODES = Object.keys(LICENSE_CODE_LABELS) as LicenseCode[];

export default function VehicleStep({ initialValue, onNext, onBack }: VehicleStepProps) {
  const [form, setForm] = useState(initialValue);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const preview = useMemo(() => {
    if (form.sumInsured <= 0) return null;
    return calculateVehiclePremium({ ...form, included: true });
  }, [form]);

  const update = <K extends keyof VehicleInput>(key: K, value: VehicleInput[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const nextErrors: Record<string, string> = {};

    if (!form.make.trim()) nextErrors.make = 'Enter the vehicle make.';
    if (!form.model.trim()) nextErrors.model = 'Enter the vehicle model.';
    if (form.sumInsured <= 0) nextErrors.sumInsured = 'Enter the sum insured amount.';
    if (form.retailValue <= 0) nextErrors.retailValue = 'Enter the retail value.';
    if (form.driverAge < 16 || form.driverAge > 100) nextErrors.driverAge = 'Enter a valid driver age.';

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    onNext({ ...form, included: true });
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-navy-900">Vehicle Details</h2>
      <p className="mt-2 text-sm text-slate-600">Tell us about the vehicle you'd like to insure.</p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-5">
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
          <div>
            <label className="block text-sm font-medium text-slate-700">Make</label>
            <input
              type="text"
              value={form.make}
              onChange={(e) => update('make', e.target.value)}
              placeholder="Toyota"
              className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
            {errors.make && <p className="mt-1.5 text-sm text-red-600">{errors.make}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Model</label>
            <input
              type="text"
              value={form.model}
              onChange={(e) => update('model', e.target.value)}
              placeholder="Corolla"
              className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
            {errors.model && <p className="mt-1.5 text-sm text-red-600">{errors.model}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Year</label>
            <input
              type="text"
              value={form.year}
              onChange={(e) => update('year', e.target.value)}
              placeholder="2021"
              className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-slate-700">Sum Insured (R)</label>
            <input
              type="number"
              min={0}
              value={form.sumInsured || ''}
              onChange={(e) => update('sumInsured', Number(e.target.value))}
              placeholder="250000"
              className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
            {errors.sumInsured && <p className="mt-1.5 text-sm text-red-600">{errors.sumInsured}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Retail Value (R)</label>
            <input
              type="number"
              min={0}
              value={form.retailValue || ''}
              onChange={(e) => update('retailValue', Number(e.target.value))}
              placeholder="260000"
              className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
            {errors.retailValue && <p className="mt-1.5 text-sm text-red-600">{errors.retailValue}</p>}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700">Fitted Extras Value (R)</label>
          <input
            type="number"
            min={0}
            value={form.extrasValue || ''}
            onChange={(e) => update('extrasValue', Number(e.target.value))}
            placeholder="15000"
            className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
          />
          <p className="mt-1.5 text-xs text-slate-500">Sound systems, canopies, rims and other non-standard fitments.</p>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-slate-700">Primary Driver Age</label>
            <input
              type="number"
              min={16}
              max={100}
              value={form.driverAge || ''}
              onChange={(e) => update('driverAge', Number(e.target.value))}
              placeholder="34"
              className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
            {errors.driverAge && <p className="mt-1.5 text-sm text-red-600">{errors.driverAge}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Driver's License Code</label>
            <select
              value={form.licenseCode}
              onChange={(e) => update('licenseCode', e.target.value as LicenseCode)}
              className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
            >
              {LICENSE_CODES.map((code) => (
                <option key={code} value={code}>
                  {LICENSE_CODE_LABELS[code]}
                </option>
              ))}
            </select>
          </div>
        </div>

        {preview && (
          <div className="rounded-lg bg-slate-50 p-4 ring-1 ring-slate-200">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-600">Estimated vehicle premium</span>
              <span className="text-lg font-bold text-navy-900">{formatCurrency(preview.totalPremium)}/mo</span>
            </div>
            {preview.loadingPct > 0 && (
              <p className="mt-1.5 text-xs text-amber-700">
                Includes a +0.5% young driver / license code loading.
              </p>
            )}
            {preview.referral && (
              <p className="mt-2 flex items-center gap-1.5 text-xs font-medium text-amber-700">
                <AlertTriangle className="h-3.5 w-3.5" /> This vehicle's retail value will require underwriting
                referral.
              </p>
            )}
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 hover:text-navy-900"
          >
            <ArrowLeft className="h-4 w-4" /> Back
          </button>
          <button
            type="submit"
            className="rounded-md bg-navy-900 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-navy-800"
          >
            Continue
          </button>
        </div>
      </form>
    </div>
  );
}
