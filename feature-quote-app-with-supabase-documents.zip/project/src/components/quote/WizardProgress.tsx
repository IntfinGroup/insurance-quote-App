interface WizardProgressProps {
  steps: string[];
  currentIndex: number;
}

export default function WizardProgress({ steps, currentIndex }: WizardProgressProps) {
  return (
    <div className="mb-10">
      <div className="flex items-center">
        {steps.map((label, index) => {
          const isComplete = index < currentIndex;
          const isCurrent = index === currentIndex;
          return (
            <div key={label} className="flex flex-1 items-center last:flex-none">
              <div className="flex flex-col items-center gap-2">
                <div
                  className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-semibold transition-colors ${
                    isComplete
                      ? 'bg-teal-600 text-white'
                      : isCurrent
                        ? 'bg-navy-900 text-white ring-4 ring-navy-100'
                        : 'bg-slate-100 text-slate-400'
                  }`}
                >
                  {isComplete ? '✓' : index + 1}
                </div>
                <span
                  className={`hidden text-xs font-medium sm:block ${
                    isCurrent ? 'text-navy-900' : 'text-slate-400'
                  }`}
                >
                  {label}
                </span>
              </div>
              {index < steps.length - 1 && (
                <div
                  className={`mx-2 h-0.5 flex-1 rounded transition-colors ${
                    isComplete ? 'bg-teal-600' : 'bg-slate-200'
                  }`}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
