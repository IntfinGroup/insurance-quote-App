import { useMemo, useState } from 'react';
import { ArrowLeft, Plus, Trash2 } from 'lucide-react';
import { AllRiskCategory, AllRiskItem, ALL_RISK_LABELS } from '@/types/insurance';
import { calculateAllRiskPremium } from '@/lib/rating';
import { formatCurrency } from '@/lib/format';

interface AllRiskStepProps {
  initialValue: AllRiskItem[];
  onNext: (items: AllRiskItem[]) => void;
  onBack: () => void;
}

const CATEGORIES = Object.keys(ALL_RISK_LABELS) as AllRiskCategory[];

function emptyItem(): AllRiskItem {
  return {
    id: crypto.randomUUID(),
    category: 'laptops_ipads_cellphones',
    description: '',
    value: 0,
  };
}

export default function AllRiskStep({ initialValue, onNext, onBack }: AllRiskStepProps) {
  const [items, setItems] = useState<AllRiskItem[]>(initialValue.length > 0 ? initialValue : [emptyItem()]);
  const [error, setError] = useState('');

  const updateItem = <K extends keyof AllRiskItem>(id: string, key: K, value: AllRiskItem[K]) => {
    setItems((prev) => prev.map((item) => (item.id === id ? { ...item, [key]: value } : item)));
  };

  const addItem = () => setItems((prev) => [...prev, emptyItem()]);
  const removeItem = (id: string) => setItems((prev) => prev.filter((item) => item.id !== id));

  const validItems = useMemo(() => items.filter((item) => item.description.trim() && item.value > 0), [items]);
  const preview = useMemo(
    () => (validItems.length > 0 ? calculateAllRiskPremium(validItems) : null),
    [validItems],
  );

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (validItems.length === 0) {
      setError('Add at least one item with a description and value.');
      return;
    }
    setError('');
    onNext(validItems);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-navy-900">All Risk / Valuables</h2>
      <p className="mt-2 text-sm text-slate-600">List the items you carry with you that you'd like covered.</p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        {items.map((item, index) => {
          const itemPremium = item.value > 0 ? calculateAllRiskPremium([item]).totalPremium : 0;
          return (
            <div key={item.id} className="rounded-xl border border-slate-200 p-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">Item {index + 1}</span>
                {items.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeItem(item.id)}
                    className="text-slate-400 hover:text-red-600"
                    aria-label="Remove item"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
              <div className="mt-3 grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="sm:col-span-1">
                  <label className="block text-xs font-medium text-slate-600">Category</label>
                  <select
                    value={item.category}
                    onChange={(e) => updateItem(item.id, 'category', e.target.value as AllRiskCategory)}
                    className="mt-1 block w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    {CATEGORIES.map((category) => (
                      <option key={category} value={category}>
                        {ALL_RISK_LABELS[category]}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-1">
                  <label className="block text-xs font-medium text-slate-600">Description</label>
                  <input
                    type="text"
                    value={item.description}
                    onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                    placeholder="MacBook Pro 14&quot;"
                    className="mt-1 block w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>
                <div className="sm:col-span-1">
                  <label className="block text-xs font-medium text-slate-600">Value (R)</label>
                  <input
                    type="number"
                    min={0}
                    value={item.value || ''}
                    onChange={(e) => updateItem(item.id, 'value', Number(e.target.value))}
                    placeholder="25000"
                    className="mt-1 block w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>
              </div>
              {itemPremium > 0 && (
                <p className="mt-2 text-right text-xs font-medium text-slate-500">
                  {formatCurrency(itemPremium)}/mo
                </p>
              )}
            </div>
          );
        })}

        <button
          type="button"
          onClick={addItem}
          className="inline-flex items-center gap-1.5 rounded-md border border-dashed border-slate-300 px-4 py-2.5 text-sm font-semibold text-slate-600 transition-colors hover:border-teal-400 hover:text-teal-700"
        >
          <Plus className="h-4 w-4" /> Add another item
        </button>

        {error && <p className="text-sm text-red-600">{error}</p>}

        {preview && (
          <div className="rounded-lg bg-slate-50 p-4 ring-1 ring-slate-200">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-600">Estimated all risk premium</span>
              <span className="text-lg font-bold text-navy-900">{formatCurrency(preview.totalPremium)}/mo</span>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 hover:text-navy-900"
          >
            <ArrowLeft className="h-4 w-4" /> Back
          </button>
          <button
            type="submit"
            className="rounded-md bg-navy-900 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-navy-800"
          >
            Continue
          </button>
        </div>
      </form>
    </div>
  );
}
