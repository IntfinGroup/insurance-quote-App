import { useMemo, useState } from 'react';
import { ArrowLeft, AlertTriangle, Info } from 'lucide-react';
import { HomeInput } from '@/types/insurance';
import { calculateHomePremium } from '@/lib/rating';
import { formatCurrency } from '@/lib/format';

interface HomeStepProps {
  initialValue: HomeInput;
  onNext: (input: HomeInput) => void;
  onBack: () => void;
}

export default function HomeStep({ initialValue, onNext, onBack }: HomeStepProps) {
  const [form, setForm] = useState(initialValue);
  const [error, setError] = useState('');

  const update = <K extends keyof HomeInput>(key: K, value: HomeInput[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const preview = useMemo(() => {
    if (!form.includeBuilding && !form.includeContents) return null;
    return calculateHomePremium(form);
  }, [form]);

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();

    if (!form.includeBuilding && !form.includeContents) {
      setError('Select at least the building or contents to continue.');
      return;
    }
    if (form.includeBuilding && form.buildingSumInsured <= 0) {
      setError('Enter a building sum insured amount.');
      return;
    }
    if (form.includeContents && form.contentsSumInsured <= 0) {
      setError('Enter a contents sum insured amount.');
      return;
    }

    setError('');
    onNext(form);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-navy-900">Home & Contents</h2>
      <p className="mt-2 text-sm text-slate-600">Insure your building, your contents, or both.</p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-6">
        <div className="rounded-xl border border-slate-200 p-5">
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={form.includeBuilding}
              onChange={(e) => update('includeBuilding', e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
            />
            <span className="text-sm font-semibold text-navy-900">Insure the building</span>
          </label>
          {form.includeBuilding && (
            <div className="mt-4">
              <label className="block text-sm font-medium text-slate-700">Building Sum Insured (R)</label>
              <input
                type="number"
                min={0}
                value={form.buildingSumInsured || ''}
                onChange={(e) => update('buildingSumInsured', Number(e.target.value))}
                placeholder="1200000"
                className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>
          )}
        </div>

        <div className="rounded-xl border border-slate-200 p-5">
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={form.includeContents}
              onChange={(e) => update('includeContents', e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
            />
            <span className="text-sm font-semibold text-navy-900">Insure the household contents</span>
          </label>
          {form.includeContents && (
            <div className="mt-4">
              <label className="block text-sm font-medium text-slate-700">Contents Sum Insured (R)</label>
              <input
                type="number"
                min={0}
                value={form.contentsSumInsured || ''}
                onChange={(e) => update('contentsSumInsured', Number(e.target.value))}
                placeholder="300000"
                className="mt-1.5 block w-full rounded-md border border-slate-300 px-3.5 py-2.5 text-sm focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
              <p className="mt-1.5 flex items-center gap-1.5 text-xs text-slate-500">
                <Info className="h-3.5 w-3.5" /> Contents are rated on a minimum sum insured of R250,000.
              </p>
            </div>
          )}
        </div>

        <label className="flex items-center gap-3 rounded-xl border border-slate-200 p-5">
          <input
            type="checkbox"
            checked={form.thatchRoof}
            onChange={(e) => update('thatchRoof', e.target.checked)}
            className="h-4 w-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
          />
          <span className="text-sm font-semibold text-navy-900">The property has a thatch roof</span>
        </label>

        {error && <p className="text-sm text-red-600">{error}</p>}

        {preview && (
          <div className="rounded-lg bg-slate-50 p-4 ring-1 ring-slate-200">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-600">Estimated home premium</span>
              <span className="text-lg font-bold text-navy-900">{formatCurrency(preview.totalPremium)}/mo</span>
            </div>
            {preview.tags.length > 0 && (
              <p className="mt-2 text-xs font-medium text-teal-700">Qualifies for: {preview.tags.join(', ')}</p>
            )}
            {preview.referral && (
              <p className="mt-2 flex items-center gap-1.5 text-xs font-medium text-amber-700">
                <AlertTriangle className="h-3.5 w-3.5" /> Combined value will require underwriting referral.
              </p>
            )}
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 hover:text-navy-900"
          >
            <ArrowLeft className="h-4 w-4" /> Back
          </button>
          <button
            type="submit"
            className="rounded-md bg-navy-900 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-navy-800"
          >
            Continue
          </button>
        </div>
      </form>
    </div>
  );
}
