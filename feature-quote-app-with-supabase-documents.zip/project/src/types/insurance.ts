export type QuoteStatus = 'draft' | 'quoted' | 'referred' | 'accepted' | 'issued';

export type LicenseCode = 'B' | 'EB' | 'C1' | 'C' | 'EC';

export interface VehicleInput {
  included: boolean;
  make: string;
  model: string;
  year: string;
  sumInsured: number;
  retailValue: number;
  extrasValue: number;
  driverAge: number;
  licenseCode: LicenseCode;
}

export interface VehicleResult {
  baseRatePct: number;
  loadingPct: number;
  effectiveRatePct: number;
  basePremium: number;
  extrasPremium: number;
  totalPremium: number;
  referral: boolean;
  referralReason: string | null;
  minimumApplied: boolean;
}

export interface HomeInput {
  includeBuilding: boolean;
  includeContents: boolean;
  buildingSumInsured: number;
  contentsSumInsured: number;
  thatchRoof: boolean;
}

export interface HomeResult {
  buildingPremium: number;
  contentsPremium: number;
  ratedContentsSumInsured: number;
  totalPremium: number;
  tags: string[];
  referral: boolean;
  referralReason: string | null;
}

export type AllRiskCategory =
  | 'laptops_ipads_cellphones'
  | 'jewelry'
  | 'cameras_glasses_firearms'
  | 'clothing_camping'
  | 'pedal_cycles';

export interface AllRiskItem {
  id: string;
  category: AllRiskCategory;
  description: string;
  value: number;
}

export interface AllRiskItemResult extends AllRiskItem {
  ratePct: number;
  premium: number;
}

export interface AllRiskResult {
  items: AllRiskItemResult[];
  totalPremium: number;
}

export type LiabilityType = 'personal' | 'public' | 'business';

export interface LiabilityInput {
  included: boolean;
  liabilityType: LiabilityType;
  limit: number;
}

export interface LiabilityResult {
  premium: number;
  referral: boolean;
  referralReason: string;
}

export interface PleasureCraftInput {
  included: boolean;
  year: string;
  make: string;
  model: string;
  sumInsured: number;
  engineType: string;
  engineManufacturer: string;
  engineSize: string;
  hullType: string;
  hullMaterial: string;
}

export interface PleasureCraftResult {
  premium: number;
  indicativeMinPremium: number;
  indicativeMaxPremium: number;
  referral: boolean;
  referralReason: string;
}

export type TrailerType = 'trailer' | 'caravan';

export interface TrailerInput {
  included: boolean;
  trailerType: TrailerType;
  year: string;
  make: string;
  model: string;
  sumInsured: number;
  coverType: 'comprehensive' | 'third_party_only';
}

export interface TrailerResult {
  premium: number;
  indicativeMinPremium: number;
  indicativeMaxPremium: number;
  referral: boolean;
  referralReason: string;
}

export interface ClientDetails {
  fullName: string;
  mobile: string;
  email: string;
}

export interface PremiumBreakdown {
  vehicle: number;
  building: number;
  contents: number;
  allRisk: number;
  liability: number;
  pleasureCraft: number;
  trailer: number;
  total: number;
}

export interface QuoteCalculation {
  vehicle: VehicleResult | null;
  home: HomeResult | null;
  allRisk: AllRiskResult | null;
  liability: LiabilityResult | null;
  pleasureCraft: PleasureCraftResult | null;
  trailer: TrailerResult | null;
  breakdown: PremiumBreakdown;
  tags: string[];
  referralReasons: string[];
  status: QuoteStatus;
}

export interface Client {
  id: string;
  full_name: string;
  mobile: string;
  email: string;
  created_at: string;
}

export interface Quote {
  id: string;
  client_id: string;
  quote_number: string;
  status: QuoteStatus;
  vehicle_section: VehicleInput | null;
  home_section: HomeInput | null;
  all_risk_section: AllRiskItem[] | null;
  liability_section: LiabilityInput | null;
  pleasure_craft_section: PleasureCraftInput | null;
  trailer_section: TrailerInput | null;
  premium_breakdown: PremiumBreakdown;
  total_monthly_premium: number;
  tags: string[];
  referral_reasons: string[];
  admin_override: boolean;
  override_reason: string | null;
  created_at: string;
  updated_at: string;
}

export interface QuoteWithClient extends Quote {
  client: Client;
}

export const ALL_RISK_LABELS: Record<AllRiskCategory, string> = {
  laptops_ipads_cellphones: 'Laptops / iPads / Cellphones',
  jewelry: 'Jewelry',
  cameras_glasses_firearms: 'Cameras / Glasses / Firearms',
  clothing_camping: 'Clothing / Camping Gear',
  pedal_cycles: 'Pedal Cycles',
};

export const LICENSE_CODE_LABELS: Record<LicenseCode, string> = {
  B: 'Code B (Light motor vehicle)',
  EB: 'Code EB (Light motor vehicle with trailer)',
  C1: 'Code C1 (Minibus / light truck)',
  C: 'Code C (Heavy truck)',
  EC: 'Code EC (Heavy truck with trailer)',
};
