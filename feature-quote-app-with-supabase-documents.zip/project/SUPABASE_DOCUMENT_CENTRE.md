# Supabase Document Centre

This version adds a private `insurance-documents` Storage bucket and a `documents` table, plus client/staff upload and download UI.

## Supabase setup

1. Open the Supabase project already configured in `.env`.
2. Go to SQL Editor.
3. Run the migration:
   `supabase/migrations/20260824133000_add_document_centre.sql`
4. Confirm Storage contains a **private** bucket called `insurance-documents`.
5. Deploy this Vite app to Vercel with the same `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` environment variables.

## Where it appears

- Client Portal: **My Documents** appears below the quote summary.
- Staff Portal: each quote drawer now has a **Documents** tab.
- Documents are linked to the client and, when uploaded from a quote, to that quote.
- Downloads use short-lived signed URLs.

## Important production security note

The supplied app currently uses a simulated OTP and broad demo `anon` RLS policies. The migration intentionally preserves that behaviour so the prototype remains usable. **Do not put real IDs, bank confirmations or other sensitive client documents into production until Supabase Auth and user/role-based RLS policies replace the demo-wide anon policies.**

The final production model should be:

Client Auth -> client can access only own client/quote/documents.
Staff Auth -> staff can access authorised client/quote/documents.
Private Storage -> signed download URLs only.
