/*
  Feature Insurance - Liability, Pleasure Craft and Trailer sections
  Source/rating note:
  - Trailer/Caravan comprehensive: 2%-4% based on value, noted R25 minimum.
  - Third Party Only: Trailer R20/month; Caravan R50/month.
  - Pleasure Craft/Watercraft: 2%-4% based on value.
  - Liability: source material does not provide a complete Feature rating formula,
    so the application refers it rather than inventing a rate.
*/
ALTER TABLE quotes
  ADD COLUMN IF NOT EXISTS liability_section jsonb,
  ADD COLUMN IF NOT EXISTS pleasure_craft_section jsonb,
  ADD COLUMN IF NOT EXISTS trailer_section jsonb;
