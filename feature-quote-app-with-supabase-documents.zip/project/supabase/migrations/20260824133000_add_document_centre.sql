-- Feature Insurance: secure client/staff document centre.
-- NOTE: the existing demo app still uses simulated OTP. Before production,
-- replace the demo-wide anon policies with Supabase Auth/RLS policies.

create table if not exists documents (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references clients(id) on delete cascade,
  quote_id uuid references quotes(id) on delete cascade,
  uploaded_by text not null check (uploaded_by in ('client','staff')),
  file_name text not null,
  file_path text not null unique,
  document_type text not null check (document_type in (
    'id_document','proof_of_address','drivers_licence','vehicle_registration',
    'bank_confirmation','valuation','invoice','policy_schedule','claim_document',
    'supporting_document','other'
  )),
  status text not null default 'uploaded' check (status in ('required','uploaded','under_review','accepted','rejected')),
  file_size bigint not null default 0,
  mime_type text not null default 'application/octet-stream',
  rejection_reason text,
  reviewed_at timestamptz,
  reviewed_by text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_documents_client_id on documents(client_id);
create index if not exists idx_documents_quote_id on documents(quote_id);
create index if not exists idx_documents_status on documents(status);

alter table documents enable row level security;

-- Demo/prototype policies. Tighten these when Supabase Auth is enabled.
drop policy if exists "anon_select_documents" on documents;
create policy "anon_select_documents" on documents for select to anon, authenticated using (true);
drop policy if exists "anon_insert_documents" on documents;
create policy "anon_insert_documents" on documents for insert to anon, authenticated with check (true);
drop policy if exists "anon_update_documents" on documents;
create policy "anon_update_documents" on documents for update to anon, authenticated using (true) with check (true);
drop policy if exists "anon_delete_documents" on documents;
create policy "anon_delete_documents" on documents for delete to anon, authenticated using (true);

insert into storage.buckets (id, name, public)
values ('insurance-documents', 'insurance-documents', false)
on conflict (id) do update set public = false;

-- Demo/prototype storage policies. Tighten these with Auth/RLS before production.
drop policy if exists "anon_read_insurance_documents" on storage.objects;
create policy "anon_read_insurance_documents" on storage.objects for select to anon, authenticated using (bucket_id = 'insurance-documents');
drop policy if exists "anon_upload_insurance_documents" on storage.objects;
create policy "anon_upload_insurance_documents" on storage.objects for insert to anon, authenticated with check (bucket_id = 'insurance-documents');
drop policy if exists "anon_delete_insurance_documents" on storage.objects;
create policy "anon_delete_insurance_documents" on storage.objects for delete to anon, authenticated using (bucket_id = 'insurance-documents');
