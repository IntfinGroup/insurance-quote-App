/*
# Feature Insurance - Core Schema

## Overview
Creates the data model backing the "Feature Insurance" quoting and policy
administration app: prospective/current clients, the quotes they request
(vehicle, home, contents and all-risk sections plus the calculated premium),
and an audit trail of every staff edit or admin override made to a quote.

This is a single-tenant, no-real-auth app: the Client Portal uses a
simulated mobile OTP flow (not Supabase Auth) and the Staff Dashboard is an
internal tool with no login system requested. Because of this, all tables
are accessed with the public anon key and RLS policies are scoped to
`anon, authenticated` with `USING (true)` — the data is intentionally
shared/open within this demo app, matching the no-sign-in pattern.

## 1. New Tables

### `clients`
- `id` (uuid, primary key) - unique client identifier
- `full_name` (text) - client's full name captured at onboarding
- `mobile` (text, unique) - South African mobile number, used as the OTP login identifier
- `email` (text) - client's email address
- `created_at` (timestamptz) - when the client record was created

### `quotes`
- `id` (uuid, primary key) - unique quote identifier
- `client_id` (uuid, FK -> clients) - owning client
- `quote_number` (text, unique) - human readable reference e.g. FI-2026-000123
- `status` (text) - one of draft, quoted, referred, accepted, issued
- `vehicle_section` (jsonb) - vehicle inputs + calculated premium detail
- `home_section` (jsonb) - building/contents inputs + calculated premium detail
- `all_risk_section` (jsonb) - itemised all-risk inputs + calculated premium detail
- `premium_breakdown` (jsonb) - per-section monthly premium summary
- `total_monthly_premium` (numeric) - sum of all section premiums
- `tags` (text[]) - descriptive tags such as "Next Level Asset"
- `referral_reasons` (text[]) - reasons the quote requires underwriting referral
- `admin_override` (boolean) - whether a staff member manually overrode the calculated result
- `override_reason` (text) - required justification for the most recent override
- `created_at` / `updated_at` (timestamptz)

### `quote_audit_log`
- `id` (uuid, primary key)
- `quote_id` (uuid, FK -> quotes) - quote that was changed
- `staff_name` (text) - staff member who made the change
- `action` (text) - short label e.g. "recalculate", "override_premium", "override_status", "edit_answers"
- `reason` (text) - required audit reason supplied by staff
- `old_value` (jsonb) - snapshot before the change
- `new_value` (jsonb) - snapshot after the change
- `created_at` (timestamptz)

## 2. Security
- RLS is enabled on all three tables.
- Each table has 4 separate policies (select/insert/update/delete) scoped to
  `anon, authenticated` with `USING (true)` / `WITH CHECK (true))`, since
  this app has no real sign-in system and both the Client Portal (simulated
  OTP) and Staff Dashboard must read/write via the anon key.

## 3. Notes
- Indexes added on `quotes.client_id`, `quotes.status` and `clients.mobile`
  for fast lookups.
- No destructive operations; safe to re-run.
*/

CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  mobile text NOT NULL UNIQUE,
  email text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS quotes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  quote_number text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'quoted', 'referred', 'accepted', 'issued')),
  vehicle_section jsonb,
  home_section jsonb,
  all_risk_section jsonb,
  premium_breakdown jsonb NOT NULL DEFAULT '{}'::jsonb,
  total_monthly_premium numeric(12,2) NOT NULL DEFAULT 0,
  tags text[] NOT NULL DEFAULT '{}',
  referral_reasons text[] NOT NULL DEFAULT '{}',
  admin_override boolean NOT NULL DEFAULT false,
  override_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS quote_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_id uuid NOT NULL REFERENCES quotes(id) ON DELETE CASCADE,
  staff_name text NOT NULL,
  action text NOT NULL,
  reason text NOT NULL,
  old_value jsonb,
  new_value jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_quotes_client_id ON quotes(client_id);
CREATE INDEX IF NOT EXISTS idx_quotes_status ON quotes(status);
CREATE INDEX IF NOT EXISTS idx_clients_mobile ON clients(mobile);
CREATE INDEX IF NOT EXISTS idx_audit_log_quote_id ON quote_audit_log(quote_id);

ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE quote_audit_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_clients" ON clients;
CREATE POLICY "anon_select_clients" ON clients FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_clients" ON clients;
CREATE POLICY "anon_insert_clients" ON clients FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_clients" ON clients;
CREATE POLICY "anon_update_clients" ON clients FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_clients" ON clients;
CREATE POLICY "anon_delete_clients" ON clients FOR DELETE
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_quotes" ON quotes;
CREATE POLICY "anon_select_quotes" ON quotes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_quotes" ON quotes;
CREATE POLICY "anon_insert_quotes" ON quotes FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_quotes" ON quotes;
CREATE POLICY "anon_update_quotes" ON quotes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_quotes" ON quotes;
CREATE POLICY "anon_delete_quotes" ON quotes FOR DELETE
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_audit_log" ON quote_audit_log;
CREATE POLICY "anon_select_audit_log" ON quote_audit_log FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_audit_log" ON quote_audit_log;
CREATE POLICY "anon_insert_audit_log" ON quote_audit_log FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_audit_log" ON quote_audit_log;
CREATE POLICY "anon_update_audit_log" ON quote_audit_log FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_audit_log" ON quote_audit_log;
CREATE POLICY "anon_delete_audit_log" ON quote_audit_log FOR DELETE
  TO anon, authenticated USING (true);
