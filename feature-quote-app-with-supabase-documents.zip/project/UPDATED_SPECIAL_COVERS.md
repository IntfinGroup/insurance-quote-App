# Updated Quote App — Liability, Pleasure Craft & Trailer / Caravan

Added to the quote wizard:
- Liability
  - Personal / Public / Business selection
  - Requested liability limit
  - Automatically referred because the supplied F4M material does not define a complete Feature rating formula.
- Pleasure Craft
  - Year, make/model, sum insured
  - Engine type/manufacturer/size
  - Hull type/material
  - F4M watercraft rate shown as 2%–4%; the app shows an indicative monthly range and refers for final rate confirmation instead of selecting a rate silently.
- Trailer / Caravan
  - Trailer vs Caravan
  - Comprehensive vs Third Party Only
  - Year, make/model, sum insured
  - Comprehensive: 2%–4% value-based range with noted R25 minimum; referred for final rate.
  - Third Party Only: Trailer R20/month; Caravan R50/month.

Database:
- Added `liability_section`, `pleasure_craft_section`, and `trailer_section` JSONB columns.
- Migration: `supabase/migrations/20260824131100_add_special_cover_sections.sql`

Important:
The F4M-derived ranges are deliberately not converted into a made-up exact production rate. The supplied rule material says ranges need explicit selection/referral logic before production use.
