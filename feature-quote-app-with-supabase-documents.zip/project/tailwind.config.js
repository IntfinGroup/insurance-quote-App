/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#eef2f7',
          100: '#d7e0ec',
          200: '#b3c4da',
          300: '#8aa3c3',
          400: '#5f7ea8',
          500: '#41618c',
          600: '#304a70',
          700: '#243a5a',
          800: '#182842',
          900: '#0f1b30',
          950: '#0a1220',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
